"""BFCL v3 원본 30문항(공통) 실행기 — 강사님 BFCL-PREPARE.md 9~13절 규칙을 팀이 다시 구현한 것.

강사님 실행기(bfcl_original.py)가 저장소에 없어서 만든 대체본이다. 같은 고정 revision·30개 ID·
변환·채점 규칙을 따르지만 강사님 코드와 한 줄씩 같지는 않으므로, 결과는 '팀 재구현 채점기' 기준으로 표시한다.
OpenAI Responses API, 표준 라이브러리만 사용. 키: OPENAI_API_KEY 또는 ~/.config/yuchion/openai_key.

  python3 run_bfcl.py self-test
  python3 run_bfcl.py run --model gpt-6-luna [--smoke]
  python3 run_bfcl.py compare results/<A> results/<B>
"""
import argparse, csv, hashlib, json, os, sys, time, urllib.error, urllib.request
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path

HERE = Path(__file__).resolve().parent
RAW, RESULTS = HERE / "raw-data", HERE / "results"
REVISION = "61fc0608cfd831fcfbbaa676ebdfef0ed963eeda"
GRADER = "team-reimpl-educational-bfcl-v3-subset-1"
FILES = ["BFCL_v3_simple.json", "BFCL_v3_multiple.json", "BFCL_v3_irrelevance.json",
         "possible_answer/BFCL_v3_simple.json", "possible_answer/BFCL_v3_multiple.json"]
EXPECTED_COUNTS = [400, 200, 240, 400, 200]
IDS = {
    "simple": "simple_149 simple_170 simple_181 simple_221 simple_242 simple_257 simple_302 simple_309 simple_367 simple_399".split(),
    "multiple": "multiple_123 multiple_134 multiple_14 multiple_16 multiple_170 multiple_178 multiple_20 multiple_24 multiple_53 multiple_69".split(),
    "irrelevance": "irrelevance_134 irrelevance_16 irrelevance_170 irrelevance_178 irrelevance_20 irrelevance_203 irrelevance_32 irrelevance_68 irrelevance_86 irrelevance_87".split(),
}
SMOKE = ["simple_149", "multiple_123", "irrelevance_134"]
TYPE_MAP = {"dict": "object", "float": "number", "integer": "integer", "string": "string", "boolean": "boolean", "array": "array", "tuple": "array", "any": None}


# ---------------- data ----------------
def jsonl(p): return {json.loads(l)["id"]: json.loads(l) for l in open(p, encoding="utf-8") if l.strip()}

def manifest():
    files = []
    for f, n in zip(FILES, EXPECTED_COUNTS):
        p = RAW / f; b = p.read_bytes(); cnt = sum(1 for l in b.decode().splitlines() if l.strip())
        assert cnt == n, f"{f}: 건수 {cnt} (기대 {n})"
        files.append({"file": f, "url": f"https://huggingface.co/datasets/gorilla-llm/Berkeley-Function-Calling-Leaderboard/resolve/{REVISION}/{f}",
                      "bytes": len(b), "records": cnt, "sha256": hashlib.sha256(b).hexdigest()})
    return {"dataset": "gorilla-llm/Berkeley-Function-Calling-Leaderboard", "revision": REVISION, "license": "Apache-2.0", "files": files, "selected_ids": IDS}

def load_cases():
    q = {k: jsonl(RAW / f"BFCL_v3_{k}.json") for k in IDS}
    a = {k: jsonl(RAW / f"possible_answer/BFCL_v3_{k}.json") for k in ("simple", "multiple")}
    cases = []
    for cat, ids in IDS.items():
        assert len(ids) == len(set(ids)) == 10
        for i in ids:
            cases.append({"id": i, "category": cat, "question": q[cat][i]["question"], "function": q[cat][i]["function"],
                          "ground_truth": a[cat][i]["ground_truth"] if cat != "irrelevance" else []})
    return cases


# ---------------- schema conversion ----------------
class AdapterError(Exception): pass

def conv(s):
    if not isinstance(s, dict): raise AdapterError(f"스키마가 객체가 아님: {s!r}")
    t = s.get("type")
    out = {}
    if t is not None:
        if t not in TYPE_MAP: raise AdapterError(f"지원하지 않는 타입: {t}")
        if TYPE_MAP[t]: out["type"] = TYPE_MAP[t]
    for k in ("description", "enum", "default"):
        if k in s: out[k] = s[k]
    if "properties" in s: out["properties"] = {k: conv(v) for k, v in s["properties"].items()}
    if "required" in s: out["required"] = list(s["required"])
    if "items" in s: out["items"] = conv(s["items"])
    elif out.get("type") == "array": out["items"] = {}
    return out

def tools_for(case):
    alias, tools = {}, []
    for f in case["function"]:
        a = "".join(ch if ch.isalnum() or ch in "_-" else "_" for ch in f["name"])
        while a in alias: a += "_"
        alias[a] = f["name"]
        params = conv(f["parameters"]); params.setdefault("type", "object")
        tools.append({"type": "function", "name": a, "description": f.get("description", ""), "parameters": params})
    return tools, alias


# ---------------- grading (강사님 문서 12절) ----------------
def type_ok(v, t):
    if t == "integer": return isinstance(v, int) and not isinstance(v, bool)
    if t == "float": return isinstance(v, (int, float)) and not isinstance(v, bool)
    if t == "boolean": return isinstance(v, bool)
    if t == "string": return isinstance(v, str)
    if t in ("array", "tuple"): return isinstance(v, list)
    if t == "dict": return isinstance(v, dict)
    return True

def same(v, allowed):
    if isinstance(allowed, bool) or isinstance(v, bool): return type(v) is type(allowed) and v == allowed
    if isinstance(allowed, (int, float)) and isinstance(v, (int, float)): return v == allowed
    if isinstance(allowed, dict):
        if not isinstance(v, dict) or set(v) - set(allowed): return False
        for k, opts in allowed.items():
            if k not in v:
                if "" not in opts: return False
            elif not any(same(v[k], o) for o in opts if o != ""): return False
        return True
    if isinstance(allowed, list): return isinstance(v, list) and len(v) == len(allowed) and all(same(x, y) for x, y in zip(v, allowed))
    return type(v) is type(allowed) and v == allowed

def check_value(v, schema, allowed, path):
    if not type_ok(v, schema.get("type")): return f"{path}: 타입 다름 ({schema.get('type')} 기대, 실제 {type(v).__name__} {v!r})"
    if "enum" in schema and v not in schema["enum"]: return f"{path}: enum 밖 값 {v!r}"
    if not any(same(v, o) for o in allowed if o != ""): return f"{path}: 허용값 아님 (실제 {v!r}, 허용 {[o for o in allowed if o != '']!r})"
    return None

def grade(case, calls, completed, text):
    if not completed: return "ERROR", "정상 완료 응답 아님"
    if case["category"] == "irrelevance":
        if calls: return "FAIL", f"호출하면 안 되는데 {len(calls)}개 호출: {', '.join(c['name'] for c in calls)}"
        if not (text or "").strip(): return "ERROR", "응답이 비어 있음(비호출 정답으로 치지 않음)"
        return "PASS", ""
    if len(calls) != 1: return "FAIL", f"호출 수 {len(calls)} (기대 1)"
    gt = case["ground_truth"][0]; fname = next(iter(gt)); allowed = gt[fname]
    c = calls[0]
    if c["name"] != fname: return "FAIL", f"함수 다름 (기대 {fname}, 실제 {c['name']})"
    f = next(x for x in case["function"] if x["name"] == fname)
    props, req = f["parameters"].get("properties", {}), set(f["parameters"].get("required", []))
    args = c["args"]
    extra = set(args) - set(props)
    if extra: return "FAIL", f"정의에 없는 인자: {sorted(extra)}"
    for p in req:
        if p not in args: return "FAIL", f"필수 인자 누락: {p}"
    for p, opts in allowed.items():
        if p not in args:
            if p in req or "" not in opts: return "FAIL", f"인자 누락: {p}"
            continue
        err = check_value(args[p], props.get(p, {}), opts, p)
        if err: return "FAIL", err
    unexpected = set(args) - set(allowed)
    if unexpected: return "FAIL", f"정답에 없는 인자 사용: {sorted(unexpected)}"
    return "PASS", ""


# ---------------- API ----------------
def api_key():
    k = os.environ.get("OPENAI_API_KEY", "").strip()
    p = Path.home() / ".config/yuchion/openai_key"
    if not k and p.exists(): k = p.read_text().strip()
    if not k: sys.exit("API 키가 없어요.")
    return k

def call_model(model, case, tools):
    msgs = case["question"][0]
    inp = [{"role": m["role"], "content": m["content"]} for m in msgs if m["role"] != "system"]
    instr = "\n".join(m["content"] for m in msgs if m["role"] == "system") or None
    body = {"model": model, "input": inp, "tools": tools, "tool_choice": "auto", "store": False}
    if instr: body["instructions"] = instr
    req = urllib.request.Request("https://api.openai.com/v1/responses", method="POST", data=json.dumps(body).encode(),
                                 headers={"Authorization": f"Bearer {api_key()}", "Content-Type": "application/json"})
    try:
        with urllib.request.urlopen(req, timeout=180) as r: return body, json.loads(r.read())
    except urllib.error.HTTPError as e:
        raise RuntimeError(f"HTTP {e.code}: {e.read().decode(errors='replace')[:400]}")


def run_one(model, case, out):
    t0 = time.time(); rec = {"id": case["id"], "category": case["category"]}
    try:
        tools, alias = tools_for(case)
    except AdapterError as e:
        rec.update(verdict="ERROR", reason=f"adapter_error: {e}", calls=[], latency_s=0); return rec
    try:
        body, resp = call_model(model, case, tools)
        (out / f"{case['id']}-request.json").write_text(json.dumps({"request": body, "alias": alias}, ensure_ascii=False, indent=2))
        (out / f"{case['id']}-raw.json").write_text(json.dumps(resp, ensure_ascii=False, indent=2))
        calls, text = [], []
        for it in resp.get("output", []):
            if it.get("type") == "function_call":
                try: args = json.loads(it["arguments"] or "{}")
                except json.JSONDecodeError: raise RuntimeError(f"인자 JSON 파싱 실패: {it['arguments'][:200]}")
                calls.append({"name": alias.get(it["name"], it["name"]), "args": args})
            elif it.get("type") == "message":
                text += [c.get("text") or c.get("refusal") or "" for c in it.get("content", [])]
        text = "\n".join(t for t in text if t)
        verdict, reason = grade(case, calls, resp.get("status") == "completed", text)
        u = resp.get("usage") or {}
        rec.update(verdict=verdict, reason=reason, calls=calls, text=text, returned_model=resp.get("model"),
                   usage={"input_tokens": u.get("input_tokens", 0), "output_tokens": u.get("output_tokens", 0)})
    except Exception as e:
        rec.update(verdict="ERROR", reason=str(e), calls=[])
    rec["latency_s"] = round(time.time() - t0, 2)
    rec["ground_truth"] = case["ground_truth"]
    (out / f"{case['id']}-result.json").write_text(json.dumps(rec, ensure_ascii=False, indent=2))
    return rec


def cmd_run(a):
    man = manifest(); cases = load_cases()
    if a.smoke: cases = [c for c in cases if c["id"] in SMOKE]
    assert len(cases) == (3 if a.smoke else 30)
    mode = "smoke_3" if a.smoke else "full_30"
    ts = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    out = RESULTS / f"{ts}-{a.model}-bfcl-{mode}"; out.mkdir(parents=True)
    (out / "SOURCE-MANIFEST.json").write_text(json.dumps(man, ensure_ascii=False, indent=2))
    rows = []
    for i, c in enumerate(cases, 1):
        r = run_one(a.model, c, out); rows.append(r)
        print(f"[{i}/{len(cases)}] {c['id']} {r['verdict']} {r.get('reason','')}", flush=True)
    tally = Counter(r["verdict"] for r in rows)
    meta = {"run_id": out.name, "evaluation": "bfcl_subset", "run_mode": mode, "grader": GRADER,
            "grader_note": "강사님 bfcl_original.py가 아닌 팀 재구현 채점기(강사님 문서 12절 규칙)", "requested_model": a.model,
            "returned_models": sorted({r.get("returned_model") for r in rows if r.get("returned_model")}),
            "api": "OpenAI Responses (store=false, tool_choice=auto, 시스템 프롬프트 없음)", "selected_ids": [c["id"] for c in cases],
            "n_selected": len(cases), "started_utc": ts, "code_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
            "tally": dict(tally), "by_category": {k: dict(Counter(r["verdict"] for r in rows if r["category"] == k)) for k in IDS},
            "usage_total": dict(sum((Counter(r.get("usage", {})) for r in rows), Counter()))}
    (out / "run.json").write_text(json.dumps(meta, ensure_ascii=False, indent=2))
    with open(out / "RESULTS.csv", "w", newline="", encoding="utf-8-sig") as f:
        w = csv.writer(f); w.writerow(["id", "category", "verdict", "reason", "calls", "latency_s"])
        for r in rows: w.writerow([r["id"], r["category"], r["verdict"], r.get("reason", ""), json.dumps(r["calls"], ensure_ascii=False), r["latency_s"]])
    L = [f"# BFCL 원본 30문항 부분 집합 평가 — {a.model}", "", f"- run_id `{out.name}` · {mode} · 선택 {len(cases)}건",
         f"- 원본 revision `{REVISION}` · 채점기 `{GRADER}` (강사님 실행기 아님, 문서 12절 규칙 재구현)",
         f"- 결과: " + ", ".join(f"{k} {v}" for k, v in sorted(tally.items())), "", "| 범주 | PASS | FAIL | ERROR |", "|---|---:|---:|---:|"]
    for k in IDS:
        c = meta["by_category"][k]; L.append(f"| {k} | {c.get('PASS',0)} | {c.get('FAIL',0)} | {c.get('ERROR',0)} |")
    L += ["", "| ID | 결과 | 이유 |", "|---|---|---|"] + [f"| {r['id']} | {r['verdict']} | {r.get('reason','')} |" for r in rows]
    (out / "SUMMARY.md").write_text("\n".join(L) + "\n")
    print(f"\n완료 {dict(tally)} → {out}")


def cmd_compare(a):
    runs = []
    for p in map(Path, a.runs):
        m = json.loads((p / "run.json").read_text())
        rows = {json.loads(f.read_text())["id"]: json.loads(f.read_text()) for f in p.glob("*-result.json")}
        if m["run_mode"] != "full_30": print(f"주의: {m['run_id']} 은 30문항 본 실행이 아님")
        runs.append((m, rows))
    names = [m["requested_model"] for m, _ in runs]
    L = ["# BFCL 원본 30문항 부분 집합 평가 — 모델 비교", "", "| 항목 | " + " | ".join(names) + " |", "|---|" + "---:|" * len(runs)]
    for v in ("PASS", "FAIL", "ERROR"): L.append(f"| {v} | " + " | ".join(str(m["tally"].get(v, 0)) for m, _ in runs) + " |")
    for k in IDS: L.append(f"| {k} PASS/10 | " + " | ".join(str(m["by_category"][k].get("PASS", 0)) for m, _ in runs) + " |")
    L.append("| 평균 응답 시간(초) | " + " | ".join(f"{sum(r['latency_s'] for r in rows.values())/len(rows):.2f}" for _, rows in runs) + " |")
    for k in ("input_tokens", "output_tokens"): L.append(f"| {k} | " + " | ".join(str(m["usage_total"].get(k, 0)) for m, _ in runs) + " |")
    L += ["", "| ID | " + " | ".join(names) + " |", "|---|" + "---|" * len(runs)]
    for i in [x for ids in IDS.values() for x in ids]:
        L.append(f"| {i} | " + " | ".join((rows[i]["verdict"] + (f" — {rows[i]['reason']}" if rows[i].get("reason") else "")) if i in rows else "-" for _, rows in runs) + " |")
    out = RESULTS / f"COMPARE-{datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%SZ')}.md"; out.write_text("\n".join(L) + "\n")
    print(out.read_text()); print("→", out)


def cmd_self_test(a):
    man = manifest(); cases = load_cases(); assert len(cases) == 30
    for c in cases:
        tools_for(c)
        if c["category"] == "irrelevance":
            assert grade(c, [], True, "답변")[0] == "PASS"; assert grade(c, [{"name": c["function"][0]["name"], "args": {}}], True, "")[0] == "FAIL"
            assert grade(c, [], True, "")[0] == "ERROR"; continue
        gt = c["ground_truth"][0]; fn = next(iter(gt))
        args = {p: next(o for o in opts if o != "") for p, opts in gt[fn].items() if any(o != "" for o in opts)}
        assert grade(c, [{"name": fn, "args": args}], True, "")[0] == "PASS", (c["id"], grade(c, [{"name": fn, "args": args}], True, ""))
        assert grade(c, [], True, "x")[0] == "FAIL"
        assert grade(c, [{"name": fn + "_x", "args": args}], True, "")[0] == "FAIL"
        k = next(iter(args)); bad = dict(args); v = bad[k]
        bad[k] = (not v) if isinstance(v, bool) else (v + 999 if isinstance(v, (int, float)) else str(v) + "_X")
        assert grade(c, [{"name": fn, "args": bad}], True, "")[0] == "FAIL", c["id"]
        assert grade(c, [{"name": fn, "args": args}], False, "")[0] == "ERROR"
    print(f"self-test 통과: 원본 5파일 건수·해시 기록, 30개 ID 결합, 정답 허용값 PASS·변조 FAIL·미완료 ERROR (모델 호출 없음)")


if __name__ == "__main__":
    p = argparse.ArgumentParser(); s = p.add_subparsers(dest="cmd", required=True)
    r = s.add_parser("run"); r.add_argument("--model", required=True); r.add_argument("--smoke", action="store_true")
    c = s.add_parser("compare"); c.add_argument("runs", nargs="+"); s.add_parser("self-test")
    a = p.parse_args(); {"run": cmd_run, "compare": cmd_compare, "self-test": cmd_self_test}[a.cmd](a)
