# BFCL 원본 30문항 부분 집합 평가 — gpt-5.4-mini

- run_id `20261117T084708Z-gpt-5.4-mini-bfcl-smoke_3` · smoke_3 · 선택 3건
- 원본 revision `61fc0608cfd831fcfbbaa676ebdfef0ed963eeda` · 채점기 `team-reimpl-educational-bfcl-v3-subset-1` (강사님 실행기 아님, 문서 12절 규칙 재구현)
- 결과: FAIL 2, PASS 1

| 범주 | PASS | FAIL | ERROR |
|---|---:|---:|---:|
| simple | 0 | 1 | 0 |
| multiple | 0 | 1 | 0 |
| irrelevance | 1 | 0 | 0 |

| ID | 결과 | 이유 |
|---|---|---|
| simple_149 | FAIL | 호출 수 2 (기대 1) |
| multiple_123 | FAIL | round_to: 허용값 아님 (실제 4, 허용 [2]) |
| irrelevance_134 | PASS |  |
