# BFCL 원본 30문항 부분 집합 평가 — gpt-6-luna

- run_id `20261117T084716Z-gpt-6-luna-bfcl-full_30` · full_30 · 선택 30건
- 원본 revision `61fc0608cfd831fcfbbaa676ebdfef0ed963eeda` · 채점기 `team-reimpl-educational-bfcl-v3-subset-1` (강사님 실행기 아님, 문서 12절 규칙 재구현)
- 결과: FAIL 9, PASS 21

| 범주 | PASS | FAIL | ERROR |
|---|---:|---:|---:|
| simple | 6 | 4 | 0 |
| multiple | 7 | 3 | 0 |
| irrelevance | 8 | 2 | 0 |

| ID | 결과 | 이유 |
|---|---|---|
| simple_149 | PASS |  |
| simple_170 | PASS |  |
| simple_181 | PASS |  |
| simple_221 | PASS |  |
| simple_242 | FAIL | discovery: 허용값 아님 (실제 'the theory of evolution', 허용 ['Theory of Evolution', 'theory of evolution']) |
| simple_257 | PASS |  |
| simple_302 | PASS |  |
| simple_309 | FAIL | team: 허용값 아님 (실제 '', 허용 ['Tampa Bay Buccaneers']) |
| simple_367 | FAIL | recipe_type: 허용값 아님 (실제 'brownies', 허용 ['dessert']) |
| simple_399 | FAIL | rating: 허용값 아님 (실제 5, 허용 [4]) |
| multiple_123 | FAIL | round_to: 허용값 아님 (실제 4, 허용 [2]) |
| multiple_134 | PASS |  |
| multiple_14 | PASS |  |
| multiple_16 | PASS |  |
| multiple_170 | PASS |  |
| multiple_178 | FAIL | deck: 허용값 아님 (실제 [], 허용 []) |
| multiple_20 | PASS |  |
| multiple_24 | PASS |  |
| multiple_53 | FAIL | 호출 수 2 (기대 1) |
| multiple_69 | PASS |  |
| irrelevance_134 | PASS |  |
| irrelevance_16 | PASS |  |
| irrelevance_170 | PASS |  |
| irrelevance_178 | PASS |  |
| irrelevance_20 | PASS |  |
| irrelevance_203 | FAIL | 호출하면 안 되는데 1개 호출: get_player_score |
| irrelevance_32 | PASS |  |
| irrelevance_68 | PASS |  |
| irrelevance_86 | FAIL | 호출하면 안 되는데 1개 호출: law_info.get_penalty |
| irrelevance_87 | PASS |  |
