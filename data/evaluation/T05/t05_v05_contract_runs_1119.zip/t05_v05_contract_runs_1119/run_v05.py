"""유치온 자체평가 30문항 v0.5 실행기 (OpenAI Responses API, 표준 라이브러리만 사용).

사용법 (이 폴더에서):
  python3 run_v05.py self-test                       # 채점기 점검 (모델 호출 없음)
  python3 run_v05.py run --mode mock                 # 가짜 모델로 저장·채점 확인 (증빙 아님)
  python3 run_v05.py models                          # 키로 쓸 수 있는 모델 ID 확인
  python3 run_v05.py run --model gpt-6-luna          # 실제 30문항 실행
  python3 run_v05.py run --model gpt-5.4-mini
  python3 run_v05.py run --model gpt-6-luna --only YC-N01,YC-M03   # 일부만 (연결 확인용)
  python3 run_v05.py compare results/<run A> results/<run B>

API 키: 환경변수 OPENAI_API_KEY, 없으면 ~/.config/yuchion/openai_key 파일 한 줄.
키는 결과 파일·로그에 저장하지 않는다.
"""
import argparse, csv, hashlib, json, os, sys, time, urllib.error, urllib.request
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path

HERE = Path(__file__).resolve().parent
SPEC_PATH = HERE.parent / "2팀_유치온_자체평가_30문항_v0.5.json"
RESULTS = HERE / "results"
API = "https://api.openai.com/v1"
FREE_TEXT = {"query", "summary", "topic"}
MAX_ROUNDS = 5
PROMPT_VERSION = os.environ.get("PROMPT_VERSION", "p1")

DEFAULT_TOOL_OUTPUT = {  # 2단계에서 가짜 결과가 지정되지 않은 뒤쪽 호출에 돌려줄 값
    "request_consultation": {"request_id": "R-2001", "status": "awaiting_teacher_confirmation"},
    "create_card": {"card_id": "CARD-2001", "status": "awaiting_review"},
    "find_consult_slots": {"teacher_id": "T-DEMO-01", "date": "2026-11-20", "slots": ["14:00", "15:30", "16:30"]},
    "get_my_requests": {"requests": []},
    "search_documents": {"results": []},
}


def load_spec():
    raw = SPEC_PATH.read_bytes()
    return json.loads(raw), hashlib.sha256(raw).hexdigest()


def system_prompt(spec):
    c = spec["context"]
    return (
        "너는 유치원 학부모용 앱 '유치온'의 AI 도우미다. 대화 상대는 학부모다.\n"
        f"오늘은 {c['today']}이다.\n"
        f"유치원: {c['kindergarten_id']} ({c['kindergarten_name']}), 반: {c['class']}.\n"
        f"이 학부모의 아이: {', '.join(c['authorized_child_ids'])}. 담임 선생님: {c['homeroom_teacher_id']}.\n"
        "필요하면 제공된 도구를 사용하고, 한국어로 답하라."
    ) + (EXTRA_RULES if PROMPT_VERSION != "p1" else "")


EXTRA_RULES = (HERE / f"rules_{PROMPT_VERSION}.txt").read_text(encoding="utf-8").rstrip() if PROMPT_VERSION != "p1" else ""


def to_schema(tool):
    props = {}
    for name, t in tool["params"].items():
        if t.startswith("ENUM"):
            props[name] = {"type": "string", "enum": t.split(" ", 1)[1].split("|")}
        elif t.startswith("BOOLEAN"):
            props[name] = {"type": "boolean"}
        else:
            p = {"type": "string"}
            if "YYYY-MM-DD" in t: p["description"] = "YYYY-MM-DD"
            if "HH:MM" in t: p["description"] = "HH:MM (24시간)"
            props[name] = p
    return {"type": "function", "function": {"name": tool["name"], "description": tool["description"],
            "parameters": {"type": "object", "properties": props, "required": tool["required"]}}}


# ---------------- scoring ----------------
def scored_args(call):
    args = {k: v for k, v in call["args"].items() if k not in FREE_TEXT}
    if call["name"] == "create_card" and args.get("request_type") == "inquiry":
        args.pop("category", None)
    return args


def key(call):
    return (call["name"], json.dumps(scored_args(call), sort_keys=True, ensure_ascii=False))


def collapse_error_retries(actual, mocks):
    """오류 가짜 결과를 받은 같은 호출은 1번까지 재시도를 허용한다."""
    out, retried = [], Counter()
    for c in actual:
        m = (mocks or {}).get(c["name"])
        if out and key(out[-1]) == key(c) and isinstance(m, dict) and "error" in m and retried[key(c)] < 1:
            retried[key(c)] += 1
            continue
        out.append(c)
    return out


def score(case, actual, final_text, error):
    if error:
        return "ERROR", error
    exp = case["expected_calls"]
    act = collapse_error_retries(actual, case.get("mock_responses"))
    if case["call_order"] == "any":
        ok = Counter(map(key, exp)) == Counter(map(key, act))
    else:
        ok = [key(c) for c in exp] == [key(c) for c in act]
    if not ok:
        return "FAIL", diff_reason(exp, act)
    if not exp and not (final_text or "").strip():
        return "FAIL", "호출 0개가 정답인데 응답 문장이 비어 있음"
    return "PASS", ""


def diff_reason(exp, act):
    en, an = [c["name"] for c in exp], [c["name"] for c in act]
    if not act and exp:
        return f"도구를 부르지 않음 (기대: {' / '.join(en)})"
    if act and not exp:
        return f"부르면 안 되는데 호출함: {' / '.join(an)}"
    if sorted(en) != sorted(an):
        return f"도구 선택/개수 다름 (기대: {' / '.join(en)}, 실제: {' / '.join(an)})"
    if Counter(map(key, exp)) == Counter(map(key, act)):
        return "호출 순서 다름"
    for e in exp:
        for a in act:
            if a["name"] == e["name"] and key(a) != key(e):
                ea, aa = scored_args(e), scored_args(a)
                bad = [f"{k}: 기대 {ea.get(k)!r}, 실제 {aa.get(k)!r}" for k in sorted(set(ea) | set(aa)) if ea.get(k) != aa.get(k)]
                return f"{e['name']} 인자 다름 ({'; '.join(bad)})"
    return "호출이 기대와 다름"


# ---------------- model backends ----------------
def api_key():
    k = os.environ.get("OPENAI_API_KEY", "").strip()
    if not k:
        p = Path.home() / ".config/yuchion/openai_key"
        if p.exists():
            k = p.read_text().strip()
    if not k:
        sys.exit("API 키가 없어요. OPENAI_API_KEY 환경변수나 ~/.config/yuchion/openai_key 파일을 준비해 주세요.")
    return k


def http(method, path, body=None):
    req = urllib.request.Request(API + path, method=method,
        data=json.dumps(body).encode() if body is not None else None,
        headers={"Authorization": f"Bearer {api_key()}", "Content-Type": "application/json"})
    try:
        with urllib.request.urlopen(req, timeout=120) as r:
            return json.loads(r.read())
    except urllib.error.HTTPError as e:
        detail = e.read().decode(errors="replace")[:500]
        raise RuntimeError(f"HTTP {e.code}: {detail}")


class OpenAIModel:
    """Responses API 어댑터. gpt-6-luna는 Chat Completions에서 추론+도구를 함께 못 써서 두 모델 모두 이 경로로 부른다.
    run_case가 쓰는 대화 형식(messages)을 Responses 입력 항목으로 바꾸고, 추론 항목까지 그대로 다시 보낸다(store=false)."""
    def __init__(self, model): self.model, self.items, self.seen = model, [], 0
    def __call__(self, messages, tools):
        instructions = next(m["content"] for m in messages if m["role"] == "system")
        for m in messages[self.seen:]:
            if m["role"] == "user":
                self.items.append({"role": "user", "content": m["content"]})
            elif m["role"] == "tool":
                self.items.append({"type": "function_call_output", "call_id": m["tool_call_id"], "output": m["content"]})
        self.seen = len(messages)
        rtools = [{"type": "function", **t["function"]} for t in tools]
        resp = http("POST", "/responses", {"model": self.model, "instructions": instructions, "input": self.items,
                    "tools": rtools, "tool_choice": "auto", "store": False, "include": ["reasoning.encrypted_content"]})
        if resp.get("status") != "completed":
            raise RuntimeError(f"응답 상태 {resp.get('status')}: {json.dumps(resp.get('incomplete_details') or resp.get('error'), ensure_ascii=False)}")
        self.items.extend(resp["output"])
        calls, text = [], []
        for it in resp["output"]:
            if it.get("type") == "function_call":
                calls.append({"id": it["call_id"], "type": "function", "function": {"name": it["name"], "arguments": it["arguments"]}})
            elif it.get("type") == "message":
                text += [c.get("text") or c.get("refusal") or "" for c in it.get("content", [])]
        msg = {"role": "assistant", "content": "\n".join(t for t in text if t) or None}
        if calls: msg["tool_calls"] = calls
        u = resp.get("usage") or {}
        return {"model": resp.get("model"), "choices": [{"message": msg}], "raw_output": resp["output"],
                "usage": {"input_tokens": u.get("input_tokens", 0), "output_tokens": u.get("output_tokens", 0),
                          "reasoning_tokens": (u.get("output_tokens_details") or {}).get("reasoning_tokens", 0)}}


class MockModel:
    """기대 호출을 그대로 내는 가짜 모델. 저장·채점 흐름 확인용이며 증빙이 아니다."""
    model = "mock"
    def __init__(self, case): self.queue, self.n = list(case["expected_calls"]), 0
    def __call__(self, messages, tools):
        self.n += 1
        if self.queue:
            batch = self.queue if (self.n == 1 and messages[-1]["role"] == "user" and self.stage1) else [self.queue[0]]
            self.queue = self.queue[len(batch):]
            calls = [{"id": f"call_{self.n}_{i}", "type": "function",
                      "function": {"name": c["name"], "arguments": json.dumps(c["args"], ensure_ascii=False)}} for i, c in enumerate(batch)]
            msg = {"role": "assistant", "content": None, "tool_calls": calls}
        else:
            msg = {"role": "assistant", "content": "(가짜 모델 응답) 확인해 볼게요."}
        return {"model": "mock", "choices": [{"message": msg, "finish_reason": "stop"}], "usage": {}}


# ---------------- runner ----------------
def run_case(case, spec, tools, model_factory):
    stage1 = case["stage"] == "decision_only" and os.environ.get("FORCE_MULTI") != "1"
    mocks = case.get("mock_responses") or {}
    msgs = [{"role": "system", "content": system_prompt(spec)}, {"role": "user", "content": case["question"]}]
    model = model_factory(case)
    if isinstance(model, MockModel): model.stage1 = stage1
    transcript, actual, final_text, error, returned_model, usage = [], [], "", "", None, Counter()
    t0 = time.time()
    try:
        for _ in range(1 if stage1 else MAX_ROUNDS):
            resp = model(msgs, tools)
            transcript.append({"request_messages": len(msgs), "response": resp})
            returned_model = resp.get("model", returned_model)
            for k, v in (resp.get("usage") or {}).items():
                if isinstance(v, int): usage[k] += v
            msg = resp["choices"][0]["message"]
            calls = msg.get("tool_calls") or []
            if msg.get("content"): final_text = msg["content"]
            for tc in calls:
                try:
                    args = json.loads(tc["function"]["arguments"] or "{}")
                except json.JSONDecodeError:
                    raise RuntimeError(f"인자 JSON 파싱 실패: {tc['function']['arguments'][:200]}")
                actual.append({"name": tc["function"]["name"], "args": args})
            if stage1 or not calls:
                break
            msgs.append({"role": "assistant", "content": msg.get("content"), "tool_calls": calls})
            for tc in calls:
                name = tc["function"]["name"]
                out = mocks.get(name, DEFAULT_TOOL_OUTPUT.get(name, {"status": "ok"}))
                msgs.append({"role": "tool", "tool_call_id": tc["id"], "content": json.dumps(out, ensure_ascii=False)})
        else:
            if not stage1: error = f"{MAX_ROUNDS}번 안에 끝나지 않음"
    except Exception as e:
        error = str(e)
    verdict, reason = score(case, actual, final_text, error)
    return {"case_id": case["case_id"], "type": case["type"], "stage": case["stage"], "flow": case["flow"],
            "question": case["question"], "verdict": verdict, "reason": reason,
            "needs_human_review": verdict == "PASS" and (not case["expected_calls"] or not stage1),
            "expected_calls": case["expected_calls"], "actual_calls": actual, "final_text": final_text,
            "returned_model": returned_model, "latency_s": round(time.time() - t0, 2), "usage": dict(usage),
            "messages_sent": msgs, "transcript": transcript}


def cmd_run(a):
    spec, sha = load_spec()
    tools = [to_schema(t) for t in spec["tools"]]
    cases = spec["cases"]
    if a.only:
        want = set(a.only.split(",")); cases = [c for c in cases if c["case_id"] in want]
        assert len(cases) == len(want), f"없는 ID: {want - {c['case_id'] for c in cases}}"
    if a.mode == "mock":
        name, factory = "mock", MockModel
    else:
        if not a.model: sys.exit("--model 을 지정해 주세요")
        name, factory = a.model, (lambda case, m=a.model: OpenAIModel(m))
    ts = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    scope = "full" if len(cases) == 30 else f"partial{len(cases)}"
    out = RESULTS / f"{ts}-{name}-{scope}"; (out / "cases").mkdir(parents=True)
    rows = []
    for i, case in enumerate(cases, 1):
        r = run_case(case, spec, tools, factory)
        (out / "cases" / f"{case['case_id']}.json").write_text(json.dumps(r, ensure_ascii=False, indent=2))
        rows.append(r)
        print(f"[{i}/{len(cases)}] {case['case_id']} {r['verdict']}{' (사람 검토 필요)' if r['needs_human_review'] else ''} {r['reason']}")
    tally = Counter(r["verdict"] for r in rows)
    meta = {"run_id": out.name, "evaluation": "team_domain", "spec_version": spec["spec_version"], "spec_sha256": sha,
            "requested_model": name, "returned_models": sorted({r["returned_model"] for r in rows if r["returned_model"]}),
            "mode": a.mode, "is_evidence": a.mode != "mock", "case_ids": [c["case_id"] for c in cases], "n_cases": len(cases),
            "started_utc": ts, "prompt_version": PROMPT_VERSION, "system_prompt": system_prompt(spec),
            "api": "responses (store=false)", "tools": tools, "tool_choice": "auto", "max_rounds": MAX_ROUNDS, "runner_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
            "tally": dict(tally), "usage_total": dict(sum((Counter(r["usage"]) for r in rows), Counter()))}
    (out / "run.json").write_text(json.dumps(meta, ensure_ascii=False, indent=2))
    with open(out / "RESULTS.csv", "w", newline="", encoding="utf-8-sig") as f:
        w = csv.writer(f)
        w.writerow(["case_id", "type", "stage", "flow", "verdict", "needs_human_review", "reason", "actual_calls", "final_text", "latency_s"])
        for r in rows:
            w.writerow([r["case_id"], r["type"], r["stage"], r["flow"], r["verdict"], r["needs_human_review"], r["reason"],
                        json.dumps(r["actual_calls"], ensure_ascii=False), r["final_text"], r["latency_s"]])
    write_summary(out, meta, rows)
    print(f"\n완료: {dict(tally)} → {out}")


def write_summary(out, meta, rows):
    L = [f"# 유치온 자체평가 v0.5 결과 — {meta['requested_model']}", "",
         f"- run_id: `{meta['run_id']}` · 문항 {meta['n_cases']}/30 · 증빙 여부: {'예' if meta['is_evidence'] else '아니오(가짜 모델)'}",
         f"- 요청 모델: `{meta['requested_model']}` · 응답에 찍힌 모델: {', '.join(meta['returned_models']) or '-'}",
         f"- 명세: {meta['spec_version']} (sha256 `{meta['spec_sha256'][:12]}`) · 프롬프트 {meta['prompt_version']} · Responses API · tool_choice auto",
         f"- 결과: " + ", ".join(f"{k} {v}" for k, v in sorted(meta["tally"].items())), "",
         "자동 채점은 함수 이름·인자(검색어·요약 제외)·호출 수·순서만 봐요. 호출 0개 문항과 2단계 문항의 응답 문장은 사람이 따로 봐야 해요.", "",
         "## 유형별", "", "| 유형 | PASS | FAIL | ERROR |", "|---|---:|---:|---:|"]
    for t in ["normal_single", "multi_step", "missing_info", "failure", "permission", "out_of_scope"]:
        c = Counter(r["verdict"] for r in rows if r["type"] == t)
        if c: L.append(f"| {t} | {c['PASS']} | {c['FAIL']} | {c['ERROR']} |")
    L += ["", "## 문항별", "", "| ID | 결과 | 사람 검토 | 이유 / 실제 호출 |", "|---|---|---|---|"]
    for r in rows:
        calls = " → ".join(c["name"] for c in r["actual_calls"]) or "호출 없음"
        L.append(f"| {r['case_id']} | {r['verdict']} | {'필요' if r['needs_human_review'] else ''} | {r['reason'] or calls} |")
    (out / "SUMMARY.md").write_text("\n".join(L) + "\n")


def cmd_compare(a):
    runs = []
    for p in a.runs:
        p = Path(p); meta = json.loads((p / "run.json").read_text())
        rows = {json.loads(f.read_text())["case_id"]: json.loads(f.read_text()) for f in (p / "cases").glob("*.json")}
        runs.append((meta, rows))
    for meta, _ in runs:
        if meta["n_cases"] != 30 or not meta["is_evidence"]:
            print(f"주의: {meta['run_id']} 는 30문항 실제 실행이 아니에요 (비교에 쓰면 안 됨)")
    ids = sorted(set().union(*[set(r) for _, r in runs]))
    L = ["# 모델 비교 — 유치온 자체평가 v0.5", "", "| 항목 | " + " | ".join(m["requested_model"] for m, _ in runs) + " |", "|---|" + "---:|" * len(runs)]
    for v in ["PASS", "FAIL", "ERROR"]:
        L.append(f"| {v} | " + " | ".join(str(m["tally"].get(v, 0)) for m, _ in runs) + " |")
    L.append("| 평균 응답 시간(초) | " + " | ".join(f"{sum(r['latency_s'] for r in rows.values())/max(len(rows),1):.2f}" for _, rows in runs) + " |")
    for k in ["input_tokens", "output_tokens", "reasoning_tokens"]:
        L.append(f"| {k} 합계 | " + " | ".join(str(m["usage_total"].get(k, '-')) for m, _ in runs) + " |")
    L += ["", "## 문항별", "", "| ID | " + " | ".join(m["requested_model"] for m, _ in runs) + " |", "|---|" + "---|" * len(runs)]
    for i in ids:
        L.append(f"| {i} | " + " | ".join((rows[i]["verdict"] + (f" — {rows[i]['reason']}" if rows[i]["reason"] else "")) if i in rows else "-" for _, rows in runs) + " |")
    out = RESULTS / f"COMPARE-{datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%SZ')}.md"
    out.write_text("\n".join(L) + "\n"); print(out.read_text()); print(f"→ {out}")


def cmd_models(a):
    data = http("GET", "/models")["data"]
    ids = sorted(m["id"] for m in data)
    for want in ["gpt-6-luna", "gpt-5.4-mini"]:
        print(f"{want}: {'있음' if want in ids else '없음'}")
    print("이 키로 쓸 수 있는 gpt 모델:", ", ".join(i for i in ids if i.startswith("gpt")))


def cmd_self_test(a):
    spec, _ = load_spec()
    assert len(spec["cases"]) == 30
    for case in spec["cases"]:
        good = run_case(case, spec, [to_schema(t) for t in spec["tools"]], MockModel)
        assert good["verdict"] == "PASS", (case["case_id"], good["reason"])
        if case["expected_calls"]:
            bad = [dict(c, args=dict(c["args"])) for c in case["expected_calls"]]
            k = next((k for k in bad[0]["args"] if k not in FREE_TEXT and not (bad[0]["name"] == "create_card" and k == "category" and bad[0]["args"].get("request_type") == "inquiry")), None)
            if k:
                v = bad[0]["args"][k]; bad[0]["args"][k] = (not v) if isinstance(v, bool) else str(v) + "_X"
                assert score(case, bad, "", "")[0] == "FAIL", case["case_id"]
            assert score(case, [], "", "")[0] == "FAIL", case["case_id"]
        else:
            assert score(case, [{"name": "search_documents", "args": {}}], "x", "")[0] == "FAIL"
            assert score(case, [], "", "")[0] == "FAIL"
    f01 = next(c for c in spec["cases"] if c["case_id"] == "YC-F01")
    assert score(f01, f01["expected_calls"] * 2, "x", "")[0] == "PASS"      # 오류 뒤 재시도 1번 허용
    assert score(f01, f01["expected_calls"] * 3, "x", "")[0] == "FAIL"      # 2번 이상은 실패
    print("self-test 통과: 30문항 정답 입력은 PASS, 인자 변조·무호출·불필요 호출은 FAIL, 오류 재시도 1회 허용 (모델 호출 없음)")


if __name__ == "__main__":
    p = argparse.ArgumentParser(); sub = p.add_subparsers(dest="cmd", required=True)
    r = sub.add_parser("run"); r.add_argument("--mode", choices=["openai", "mock"], default="openai"); r.add_argument("--model"); r.add_argument("--only")
    c = sub.add_parser("compare"); c.add_argument("runs", nargs="+")
    sub.add_parser("models"); sub.add_parser("self-test")
    a = p.parse_args()
    {"run": cmd_run, "compare": cmd_compare, "models": cmd_models, "self-test": cmd_self_test}[a.cmd](a)
