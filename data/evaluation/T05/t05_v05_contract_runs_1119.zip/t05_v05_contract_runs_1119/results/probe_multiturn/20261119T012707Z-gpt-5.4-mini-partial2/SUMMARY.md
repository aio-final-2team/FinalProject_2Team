# 유치온 자체평가 v0.5 결과 — gpt-5.4-mini

- run_id: `20261119T012707Z-gpt-5.4-mini-partial2` · 문항 2/30 · 증빙 여부: 예
- 요청 모델: `gpt-5.4-mini` · 응답에 찍힌 모델: gpt-5.4-mini-2026-03-17
- 명세: yuchion-v0.5 (sha256 `7ba5899c0e65`) · 프롬프트 p1 · Responses API · tool_choice auto
- 결과: FAIL 2

자동 채점은 함수 이름·인자(검색어·요약 제외)·호출 수·순서만 봐요. 호출 0개 문항과 2단계 문항의 응답 문장은 사람이 따로 봐야 해요.

## 유형별

| 유형 | PASS | FAIL | ERROR |
|---|---:|---:|---:|
| normal_single | 0 | 1 | 0 |
| multi_step | 0 | 1 | 0 |

## 문항별

| ID | 결과 | 사람 검토 | 이유 / 실제 호출 |
|---|---|---|---|
| YC-N10 | FAIL |  | create_card 인자 다름 (topic_key: 기대 'teacher', 실제 'safety') |
| YC-M07 | FAIL |  | 도구 선택/개수 다름 (기대: search_documents / create_card, 실제: search_documents / search_documents / create_card) |
