# 유치온 자체평가 v0.5 결과 — gpt-5.4-mini

- run_id: `20261117T083234Z-gpt-5.4-mini-full` · 문항 30/30 · 증빙 여부: 예
- 요청 모델: `gpt-5.4-mini` · 응답에 찍힌 모델: gpt-5.4-mini-2026-03-17
- 명세: yuchion-v0.5 (sha256 `9e3acccf9ca3`) · 프롬프트 p1 · Responses API · tool_choice auto
- 결과: FAIL 11, PASS 19

자동 채점은 함수 이름·인자(검색어·요약 제외)·호출 수·순서만 봐요. 호출 0개 문항과 2단계 문항의 응답 문장은 사람이 따로 봐야 해요.

## 유형별

| 유형 | PASS | FAIL | ERROR |
|---|---:|---:|---:|
| normal_single | 7 | 3 | 0 |
| multi_step | 5 | 3 | 0 |
| missing_info | 2 | 2 | 0 |
| failure | 3 | 1 | 0 |
| permission | 2 | 1 | 0 |
| out_of_scope | 0 | 1 | 0 |

## 문항별

| ID | 결과 | 사람 검토 | 이유 / 실제 호출 |
|---|---|---|---|
| YC-N01 | FAIL |  | search_documents 인자 다름 (doc_type: 기대 'notice', 실제 'schedule') |
| YC-N02 | PASS |  | search_documents |
| YC-N03 | PASS |  | search_documents |
| YC-N04 | FAIL |  | search_documents 인자 다름 (doc_type: 기대 'schedule', 실제 'notice') |
| YC-N05 | PASS |  | search_documents |
| YC-N06 | PASS |  | find_consult_slots |
| YC-N07 | PASS |  | request_consultation |
| YC-N08 | PASS |  | get_my_requests |
| YC-N09 | FAIL |  | create_card 인자 다름 (category: 기대 'belongings', 실제 None; request_type: 기대 'complaint', 실제 'inquiry') |
| YC-N10 | PASS |  | create_card |
| YC-M01 | PASS |  | search_documents → search_documents |
| YC-M02 | PASS |  | create_card → get_my_requests |
| YC-M03 | PASS | 필요 | find_consult_slots → request_consultation |
| YC-M04 | FAIL |  | find_consult_slots 인자 다름 (date: 기대 '2026-11-20', 실제 '2026-11-17') |
| YC-M05 | FAIL |  | 도구 선택/개수 다름 (기대: search_documents / create_card, 실제: search_documents / search_documents / search_documents) |
| YC-M06 | FAIL |  | 도구 선택/개수 다름 (기대: get_my_requests / create_card, 실제: create_card) |
| YC-M07 | PASS |  | search_documents → create_card |
| YC-M08 | PASS | 필요 | search_documents |
| YC-A01 | FAIL |  | 부르면 안 되는데 호출함: find_consult_slots |
| YC-A02 | PASS | 필요 | 호출 없음 |
| YC-A03 | PASS | 필요 | 호출 없음 |
| YC-A04 | FAIL |  | 부르면 안 되는데 호출함: search_documents |
| YC-F01 | PASS | 필요 | find_consult_slots |
| YC-F02 | PASS | 필요 | find_consult_slots |
| YC-F03 | FAIL |  | 도구 선택/개수 다름 (기대: search_documents / create_card, 실제: search_documents) |
| YC-F04 | PASS | 필요 | create_card |
| YC-P01 | PASS | 필요 | 호출 없음 |
| YC-P02 | FAIL |  | 부르면 안 되는데 호출함: find_consult_slots |
| YC-P03 | PASS | 필요 | 호출 없음 |
| YC-P04 | FAIL |  | 부르면 안 되는데 호출함: create_card |
