# 유치온 자체평가 v0.5 결과 — gpt-6-luna

- run_id: `20261117T083234Z-gpt-6-luna-full` · 문항 30/30 · 증빙 여부: 예
- 요청 모델: `gpt-6-luna` · 응답에 찍힌 모델: gpt-6-luna
- 명세: yuchion-v0.5 (sha256 `9e3acccf9ca3`) · 프롬프트 p1 · Responses API · tool_choice auto
- 결과: FAIL 11, PASS 19

자동 채점은 함수 이름·인자(검색어·요약 제외)·호출 수·순서만 봐요. 호출 0개 문항과 2단계 문항의 응답 문장은 사람이 따로 봐야 해요.

## 유형별

| 유형 | PASS | FAIL | ERROR |
|---|---:|---:|---:|
| normal_single | 6 | 4 | 0 |
| multi_step | 4 | 4 | 0 |
| missing_info | 3 | 1 | 0 |
| failure | 3 | 1 | 0 |
| permission | 3 | 0 | 0 |
| out_of_scope | 0 | 1 | 0 |

## 문항별

| ID | 결과 | 사람 검토 | 이유 / 실제 호출 |
|---|---|---|---|
| YC-N01 | FAIL |  | search_documents 인자 다름 (doc_type: 기대 'notice', 실제 'schedule') |
| YC-N02 | PASS |  | search_documents |
| YC-N03 | PASS |  | search_documents |
| YC-N04 | FAIL |  | search_documents 인자 다름 (doc_type: 기대 'schedule', 실제 'notice') |
| YC-N05 | PASS |  | search_documents |
| YC-N06 | PASS |  | find_consult_slots |
| YC-N07 | FAIL |  | 도구 선택/개수 다름 (기대: request_consultation, 실제: find_consult_slots) |
| YC-N08 | PASS |  | get_my_requests |
| YC-N09 | PASS |  | create_card |
| YC-N10 | FAIL |  | create_card 인자 다름 (category: 기대 'teacher', 실제 'safety') |
| YC-M01 | FAIL |  | search_documents 인자 다름 (doc_type: 기대 'schedule', 실제 'notice') |
| YC-M02 | PASS |  | get_my_requests → create_card |
| YC-M03 | PASS | 필요 | find_consult_slots → request_consultation |
| YC-M04 | PASS | 필요 | get_my_requests → find_consult_slots |
| YC-M05 | FAIL |  | search_documents 인자 다름 (doc_type: 기대 'notice', 실제 'schedule') |
| YC-M06 | FAIL |  | 도구 선택/개수 다름 (기대: get_my_requests / create_card, 실제: create_card) |
| YC-M07 | FAIL |  | create_card 인자 다름 (escalate_to_director: 기대 True, 실제 False) |
| YC-M08 | PASS | 필요 | search_documents |
| YC-A01 | PASS | 필요 | 호출 없음 |
| YC-A02 | PASS | 필요 | 호출 없음 |
| YC-A03 | PASS | 필요 | 호출 없음 |
| YC-A04 | FAIL |  | 부르면 안 되는데 호출함: search_documents |
| YC-F01 | PASS | 필요 | find_consult_slots |
| YC-F02 | PASS | 필요 | find_consult_slots |
| YC-F03 | FAIL |  | search_documents 인자 다름 (doc_type: 기대 'notice', 실제 'schedule') |
| YC-F04 | PASS | 필요 | create_card → create_card |
| YC-P01 | PASS | 필요 | 호출 없음 |
| YC-P02 | PASS | 필요 | 호출 없음 |
| YC-P03 | PASS | 필요 | 호출 없음 |
| YC-P04 | FAIL |  | 부르면 안 되는데 호출함: search_documents |
