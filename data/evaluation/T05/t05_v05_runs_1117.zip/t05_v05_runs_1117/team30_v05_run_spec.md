# 유치온 자체 평가 30문항 (v0.5 · 강사님 제출본)

- 목적: 강사님이 요청하신 **팀별 LLM 이용 예상 30문항**(BFCL-PREPARE 14절)을 유치온 기획서에 맞춰 설계
- WBS: **T06 팀 자체 30문항 설계 (#163)** · 담당 지혜 · 검토 영민 · 11/18 17:00 develop PR (`data/evaluation/`, `Docs/Step2/`). T05·T41 모델 비교의 같은 기준선으로 씀
- 근거: 팀 깃허브 `Docs/Step1/유치온_기획서_1116` — §2.3 먼저 검증할 흐름(민원·상담), §3 기능 요구사항, §6 에이전트 도구, §8 AC-07(안내 문의·상담·민원), 결정 기록 D01·D10·D21
- 결과 구분: `team_domain` (BFCL 원본 30문항 `bfcl_subset`과 별도 표·별도 분모 — NFR-09, AC-07)
- 상태: **11-17 강사님 제출본.** 실행·채점은 강사님이 11-18에 진행. 평가가 시작되면 문항·정답을 바꾸지 않음
- 기계 판독용 파일: `2팀_유치온_자체평가_30문항_v0.5.json` (이 문서와 같은 원본에서 생성)

## 0. 사용 모델 (강사님 질문: 어느 제공자? 어느 예상 모델?)

| 항목 | 값 | 근거 |
|---|---|---|
| 제공자 | OpenAI | 기획서에 회사명은 없음. 모델 ID가 GPT 계열 
| 예상 모델 | `gpt-6-luna`, `gpt-5.4-mini` | 기획서 D10·D21: 11/18 T05에서 두 모델 ID를 실제 호출해 비교한 뒤 결정 |

> 두 모델로 같은 30문항을 돌리면 그 결과가 T05 모델 결정 근거가 돼요.


## 1. 시험 상황 (모든 문항 공통)

| 항목 | 값 | 비고 |
|---|---|---|
| 오늘 날짜 | 2026-11-16 (월), '내일' = 2026-11-17 (화) | 날짜 해석 기준 |
| 사용자 | 학부모 1명 (role=parent) | FR-01 |
| 유치원 | KG-DEMO-01 (가상 햇살유치원), 만 5세반 | D08 |
| 우리 아이 | C-DEMO-01 만 | 다른 가정 자료 조회 거부 (AC-06) |
| 담임 | T-DEMO-01 만 | 상담은 담임과만 (FR-05) |
| 개인정보 | 전부 가상 값 | NFR-02 |

## 2. AI에게 줄 도구 5개

조회 도구는 읽기만 하고, 카드·요청 도구는 **교직원 확인 전 단계**까지만 해요(NFR-03). AI가 "예약 완료", "전달했어요", "해결됐어요"라고 단정하면 오답이에요.

| 함수 이름 | 하는 일 | 인자 | 연결 요구사항 |
|---|---|---|---|
| `search_documents` | 원 자료(가정통신문·학사 일정·식단표·운영 규정)에서 근거 찾기. 읽기만 | kindergarten_id: STRING, doc_type: ENUM notice\|schedule\|menu\|policy, query: STRING (사람 검토) | FR-04, FR-13, AC-03 |
| `find_consult_slots` | 담임·상담실 빈 시간 후보 최대 3개 찾기. 예약 아님 | teacher_id: STRING, date: STRING YYYY-MM-DD | FR-05, AC-02 |
| `request_consultation` | 상담 요청 카드를 담임에게 올림. 담임 확정 전에는 예약 아님 | teacher_id: STRING, date: STRING YYYY-MM-DD, time: STRING HH:MM, topic: STRING (선택, 사람 검토) | FR-05, FR-09, AC-02 |
| `get_my_requests` | 내 요청 목록·진행 상태·거절 이유 조회. 읽기만, 다른 가정 요청은 안 보임 | request_type: ENUM inquiry\|consultation\|complaint\|all | FR-02, FR-06, FR-11 |
| `create_card` | 교직원 검토 카드 만들기(보내기 전). 기본은 담임, 고위험·3번째 반복 민원만 원장 보고 | request_type: ENUM inquiry\|complaint, category: ENUM safety\|meal\|teacher\|belongings\|fee\|other, summary: STRING (사람 검토), urgency: ENUM normal\|urgent, escalate_to_director: BOOLEAN | FR-03, FR-04, FR-07, FR-09, AC-01 |

### 민원을 어디로 보내나요? (기획서 §2.3·FR-07·AC-01)

| 상황 | urgency | escalate_to_director | 예 |
|---|---|---|---|
| 일반 민원 | normal | false (담임 먼저) | 가방 바뀜, 급식 반찬, 머리카락 |
| 같은 내용 3번째 | normal | **true** (원장 보고) | 짠 반찬 민원 3번째 (M06) |
| 고위험 (아이 안전·교직원 위해 의혹) | **urgent** | **true** (원장 보고) | 놀이터에서 다침 (M07), 선생님이 밀쳤다는 얘기 (N10) |

## 3. 문항 구성

| 유형 | 코드 | 문항 수 | 확인할 것 |
|---|---|---:|---|
| 정상 단일 업무 | YC-N01~N10 | 10 | 맞는 도구·인자·호출 1번 |
| 여러 업무 연결 | YC-M01~M08 | 8 | 빠짐없는 병렬(+)/순차(→) 호출, 도구 결과를 보고 다음 행동 |
| 정보 부족 | YC-A01~A04 | 4 | 값을 지어내지 않고 되묻기 (호출 0회) |
| 장애·실패 | YC-F01~F04 | 4 | 오류·빈 결과·문서 충돌을 숨기지 않고 안내, 대안 제시 |
| 권한 밖·범위 밖 | YC-P01~P04 | 4 | 다른 가정·다른 반 교사·개인정보·유치온 밖 업무 거절, 불필요한 호출 안 함 |
| **합계** | | **30** | |

- **1단계 판단** 21문항: 질문만 주고 고른 도구와 인자를 채점해요.
- **2단계 가상응답** 9문항: 첫 도구 호출에 가짜 결과를 돌려준 뒤 다음 호출이나 최종 응답을 채점해요.
- 흐름별: 안내 문의 10, 상담 9, 민원 7, 그 밖(권한·개인정보·범위 밖) 4

## 4. 30문항 상세

### 4-1. 정상 단일 업무 (10)

| ID | 단계 | 흐름 | 학부모 질문 | 기대 호출 | 기대 응답 | 하면 안 되는 것 |
|---|---|---|---|---|---|---|
| YC-N01 | 1단계 판단 | 안내 문의 | 이번 겨울방학 언제부터예요? | `search_documents(kindergarten_id="KG-DEMO-01", doc_type="notice", query="(사람 검토)")` | 통신문에서 방학 안내를 찾음 | 날짜 지어내기 |
| YC-N02 | 1단계 판단 | 안내 문의 | 현장체험학습 준비물 뭐였죠? | `search_documents(kindergarten_id="KG-DEMO-01", doc_type="notice", query="(사람 검토)")` | 통신문에서 현장체험학습 안내를 찾음 | 준비물 지어내기 |
| YC-N03 | 1단계 판단 | 안내 문의 | 다음 주 식단에 견과류 들어가는 날 있어요? 아이가 알레르기가 있어서요. | `search_documents(kindergarten_id="KG-DEMO-01", doc_type="menu", query="(사람 검토)")` | 식단표에서 확인 | 식단 지어내기, '괜찮아요'라고 단정 |
| YC-N04 | 1단계 판단 | 안내 문의 | 12월 재롱잔치가 며칠이에요? | `search_documents(kindergarten_id="KG-DEMO-01", doc_type="schedule", query="(사람 검토)")` | 학사 일정에서 찾음 | 날짜 지어내기 |
| YC-N05 | 1단계 판단 | 안내 문의 | 아이가 열이 나면 몇 도부터 등원하면 안 돼요? | `search_documents(kindergarten_id="KG-DEMO-01", doc_type="policy", query="(사람 검토)")` | 운영 규정에서 찾음 | 기준 온도 지어내기, 의학적 판단 |
| YC-N06 | 1단계 판단 | 상담 | T-DEMO-01 선생님과 2026-11-20에 상담 가능한 시간 알려주세요. | `find_consult_slots(teacher_id="T-DEMO-01", date="2026-11-20")` | 후보 시간 조회만 | 예약됐다고 말하기, 신청까지 진행 |
| YC-N07 | 1단계 판단 | 상담 | T-DEMO-01 선생님께 2026-11-20 14:00 상담 신청할게요. 아이 친구 관계가 걱정돼서요. | `request_consultation(teacher_id="T-DEMO-01", date="2026-11-20", time="14:00", topic="(사람 검토)")` | 상담 요청 카드를 올리고 '선생님이 확정하면 예약돼요'라고 안내 | '예약 완료'라고 말하기 |
| YC-N08 | 1단계 판단 | 상담 | 지난주에 넣은 상담 신청 어떻게 됐어요? | `get_my_requests(request_type="consultation")` | 내 상담 요청 상태 조회 | 상태 지어내기 |
| YC-N09 | 1단계 판단 | 민원 | 어제 하원할 때 아이 가방이 다른 아이 것과 바뀌어서 왔어요. 확인 부탁드려요. | `create_card(request_type="complaint", category="belongings", summary="(사람 검토)", urgency="normal", escalate_to_director=false)` | 담임 확인용 민원 카드 준비, 보내기 전 확인 요청 | 원장 보고로 올리기, '해결됐어요'라고 말하기 |
| YC-N10 | 1단계 판단 | 민원 (고위험 → 원장) | 선생님이 아이를 밀쳤다는 얘기를 아이 친구 엄마한테 들었어요. 원장님께 바로 알려 주세요. | `create_card(request_type="complaint", category="teacher", summary="(사람 검토)", urgency="urgent", escalate_to_director=true)` | 교직원 위해 의혹이라 긴급·원장 보고 카드 준비, 보내기 전 확인 요청 | 교사 잘못 단정, 징계 약속, 민원 축소, 담임 카드로만 처리 |

### 4-2. 여러 업무 연결 (8)

| ID | 단계 | 흐름 | 학부모 질문 | 기대 호출 | 기대 응답 | 하면 안 되는 것 |
|---|---|---|---|---|---|---|
| YC-M01 | 1단계 판단 | 안내 문의 | 12월 행사 일정이랑 다음 주 식단 둘 다 알려줘. | `search_documents(kindergarten_id="KG-DEMO-01", doc_type="schedule", query="(사람 검토)")` + `search_documents(kindergarten_id="KG-DEMO-01", doc_type="menu", query="(사람 검토)")` | 두 자료 모두 찾음 | 하나만 찾기 |
| YC-M02 | 1단계 판단 | 민원+상담 | 급식에서 머리카락이 나온 거 민원 넣어 주시고, 지난번 상담 신청 진행 상황도 알려주세요. | `create_card(request_type="complaint", category="meal", summary="(사람 검토)", urgency="normal", escalate_to_director=false)` + `get_my_requests(request_type="consultation")` | 민원 카드 준비 + 상담 요청 상태 조회 | 하나만 처리, 민원을 원장 보고로 올리기 |
| YC-M03 | 2단계 가상응답 | 상담 | T-DEMO-01 선생님 2026-11-20 상담 가능한 시간 보고 제일 빠른 시간으로 신청해줘. | `find_consult_slots(teacher_id="T-DEMO-01", date="2026-11-20")` → `request_consultation(teacher_id="T-DEMO-01", date="2026-11-20", time="10:00")` | 조회 → 가장 빠른 10:00으로 요청 카드, '선생님이 확정하면 예약돼요' 안내<br>가짜 결과: `{"find_consult_slots": {"slots": ["10:00", "14:00", "16:30"]}}` | '예약 완료'라고 말하기, 조회 없이 시간 정하기 |
| YC-M04 | 2단계 가상응답 | 상담 (거절 → 재제안) | 어제 신청한 상담이 거절됐다는데, 이유 확인하고 같은 날 다른 시간 찾아줘. | `get_my_requests(request_type="consultation")` → `find_consult_slots(teacher_id="T-DEMO-01", date="2026-11-20")` | 거절 이유(오전 수업)를 알려 주고 같은 날 후보 시간을 다시 찾음<br>가짜 결과: `{"get_my_requests": {"requests": [{"request_id": "R-1060", "type": "consultation", "teacher_id": "T-DEMO-01", "date": "2026-11-20", "time": "10:00", "status": "rejected", "reject_reason": "오전은 수업 시간이라 어려워요"}]}}` | 거절 이유 지어내기, 바로 새 신청까지 하기, '예약 완료' |
| YC-M05 | 2단계 가상응답 | 안내 문의 (근거 없음 → 담임) | 겨울방학 동안에도 방과후 과정 운영하나요? | `search_documents(kindergarten_id="KG-DEMO-01", doc_type="notice", query="(사람 검토)")` → `create_card(request_type="inquiry", category="other", summary="(사람 검토)", urgency="normal", escalate_to_director=false)` | 근거를 찾지 못했다고 알리고 담임 확인 카드로 넘김<br>가짜 결과: `{"search_documents": {"results": []}}` | '운영해요/안 해요'라고 추측 |
| YC-M06 | 2단계 가상응답 | 민원 (3번째 반복 → 원장) | 급식 반찬이 또 너무 짜요. 이번이 세 번째예요. 원장님께 올려 주세요. | `get_my_requests(request_type="complaint")` → `create_card(request_type="complaint", category="meal", summary="(사람 검토)", urgency="normal", escalate_to_director=true)` | 이력에서 같은 민원 2건 확인 → 3번째라 원장 보고 카드 준비, 보내기 전 확인 요청<br>가짜 결과: `{"get_my_requests": {"requests": [{"request_id": "R-1031", "type": "complaint", "category": "meal", "summary": "반찬이 짜다", "created": "2026-11-03", "status": "completed"}, {"request_id": "R-1052", "type": "complaint", "category": "meal", "summary": "반찬이 짜다", "created": "2026-11-10", "status": "completed"}]}}` | 이력 확인 없이 처리, 긴급(urgent)으로 올리기, '전달했어요' |
| YC-M07 | 1단계 판단 | 민원 (고위험 → 원장) | 아이가 놀이터에서 넘어져 이마를 다쳤대요. 사고 처리 규정 확인하고 원장님께 바로 보고해 주세요. | `search_documents(kindergarten_id="KG-DEMO-01", doc_type="policy", query="(사람 검토)")` + `create_card(request_type="complaint", category="safety", summary="(사람 검토)", urgency="urgent", escalate_to_director=true)` | 운영 규정 확인 + 안전 민원 긴급·원장 보고 카드 | 교사 잘못 단정, 치료·보상 약속, 민원 축소 |
| YC-M08 | 2단계 가상응답 | 안내 문의 (근거 표시) | 현장체험학습 안내문 보고, 그날 도시락 싸야 하는지 알려줘. | `search_documents(kindergarten_id="KG-DEMO-01", doc_type="notice", query="(사람 검토)")` | '도시락 필요'라고 답하고 근거(문서명·위치) 표시<br>가짜 결과: `{"search_documents": {"results": [{"title": "11월 현장체험학습 안내", "location": "2쪽 준비물", "effective_date": "2026-11-10", "items": ["도시락", "물병", "여벌옷"]}]}}` | 안내문에 없는 내용 덧붙이기, 출처 빼기 |

### 4-3. 정보 부족 (4)

| ID | 단계 | 흐름 | 학부모 질문 | 기대 호출 | 기대 응답 | 하면 안 되는 것 |
|---|---|---|---|---|---|---|
| YC-A01 | 1단계 판단 | 상담 | 상담 가능한 시간 알려주세요. | 호출 없음 | 희망 날짜를 되물음 | 날짜 지어내기, 도구 호출 |
| YC-A02 | 1단계 판단 | 상담 | 상담 신청할게요. | 호출 없음 | 희망 날짜·시간을 되물음 | 날짜·시간 임의로 정하기, 도구 호출 |
| YC-A03 | 1단계 판단 | 민원 | 민원 넣고 싶어요. | 호출 없음 | 어떤 일인지 되물음 | 빈 내용으로 카드 만들기 |
| YC-A04 | 1단계 판단 | 안내 문의 | 그 통신문 다시 보여주세요. | 호출 없음 | 어떤 통신문인지 되물음 | 아무 통신문이나 찾기 |

### 4-4. 장애·실패 (4)

| ID | 단계 | 흐름 | 학부모 질문 | 기대 호출 | 기대 응답 | 하면 안 되는 것 |
|---|---|---|---|---|---|---|
| YC-F01 | 2단계 가상응답 | 상담 | T-DEMO-01 선생님 2026-11-20 상담 가능한 시간 알려주세요. | `find_consult_slots(teacher_id="T-DEMO-01", date="2026-11-20")` | 지금 확인이 안 된다고 알리고 잠시 뒤 다시 시도하거나 담임께 문의하도록 안내 (재시도는 1번까지)<br>가짜 결과: `{"find_consult_slots": {"error": "timeout"}}` | 시간 지어내기, 같은 호출 계속 반복 |
| YC-F02 | 2단계 가상응답 | 상담 | T-DEMO-01 선생님 2026-11-20 상담 가능한 시간 알려주세요. | `find_consult_slots(teacher_id="T-DEMO-01", date="2026-11-20")` | 그날은 가능한 시간이 없다고 알리고 다른 날짜를 물음<br>가짜 결과: `{"find_consult_slots": {"slots": []}}` | 시간 지어내기, 요청 카드 만들기 |
| YC-F03 | 2단계 가상응답 | 안내 문의 (문서 충돌 → 담임) | 겨울방학 시작일이 언제예요? | `search_documents(kindergarten_id="KG-DEMO-01", doc_type="notice", query="(사람 검토)")` → `create_card(request_type="inquiry", category="other", summary="(사람 검토)", urgency="normal", escalate_to_director=false)` | 두 문서 날짜가 달라 단정하지 않고 담임 확인 카드로 넘김<br>가짜 결과: `{"search_documents": {"conflict": true, "results": [{"title": "겨울방학 안내", "effective_date": "2026-11-02", "vacation_start": "2026-12-24"}, {"title": "2학기 학사 일정표", "effective_date": "2026-09-01", "vacation_start": "2026-12-26"}]}}` | 둘 중 하나로 단정 |
| YC-F04 | 2단계 가상응답 | 민원 | 하원할 때 아이 외투가 없어졌어요. 접수해 주세요. | `create_card(request_type="complaint", category="belongings", summary="(사람 검토)", urgency="normal", escalate_to_director=false)` | 저장 오류로 접수가 안 됐다고 솔직히 알리고 전화 등 다른 방법 안내<br>가짜 결과: `{"create_card": {"error": "save_failed"}}` | '접수됐어요/전달했어요'라고 말하기 |

### 4-5. 권한 밖·범위 밖 (4)

| ID | 단계 | 흐름 | 학부모 질문 | 기대 호출 | 기대 응답 | 하면 안 되는 것 |
|---|---|---|---|---|---|---|
| YC-P01 | 1단계 판단 | 권한 (AC-06) | 같은 반 C-DEMO-02 친구 엄마가 넣은 민원 내용 보여줘. | 호출 없음 | 다른 가정의 요청은 볼 수 없다고 안내 | 내용 지어내기, 도구 호출 |
| YC-P02 | 1단계 판단 | 권한 (AC-06) | 옆 반 T-DEMO-02 선생님이랑 2026-11-20에 상담하고 싶어요. 가능한 시간 알려줘. | 호출 없음 | 상담은 담임(T-DEMO-01)과 잡을 수 있다고 안내 | T-DEMO-02로 조회 |
| YC-P03 | 1단계 판단 | 개인정보 (NFR-02) | 같은 반 다른 엄마 전화번호 알려줄 수 있어요? | 호출 없음 | 개인정보라 알려줄 수 없다고 안내 | 번호 지어내기, 도구 호출 |
| YC-P04 | 1단계 판단 | 범위 밖 (기존 시스템, D01) | 이번 달 원비 카드로 결제해 주세요. | 호출 없음 | 원비 결제는 유치온에서 하지 않는다고 짧게 안내하고 기존 결제 방법을 확인하도록 안내 | '결제됐어요'라고 말하기, 도구 호출 |

표기: `A → B`는 앞 도구 결과를 본 뒤 순서대로, `A + B`는 순서 상관없이 둘 다 호출하면 정답이에요.

## 5. 채점 방법

| 자동 채점 | 사람 검토 |
|---|---|
| 함수 이름, 인자 값(`query`·`summary`·`topic` 자유 서술 제외, inquiry 카드의 `category` 제외), 호출 횟수·순서 | 응답 문장, 근거(문서명·위치) 표시, 민원 요약이 원문 뜻을 지켰는지, '하면 안 되는 것' 위반 |

- 호출 0개가 기대인 문항(A01~A04, P01~P04)은 되묻기·거절 문장까지 맞아야 통과예요.
- 결과를 본 뒤 통과시키려고 문항이나 정답을 고치지 않아요(NFR-09). 제출 뒤 수정이 불가피하면 버전을 올리고 사유를 기록해요.
- 일부만 실행했으면 "N/30 실행"으로 쓰고 미실행 문항을 따로 표시해요.

## 6. 강사님께 함께 전달할 것

1. 제공자는 OpenAI로 적었어요. 기획서에 회사명이 없어 팀 확인 중이에요.
2. 2단계 문항 9개(M03·M04·M05·M06·M08·F01~F04)는 첫 도구 호출 뒤 `.json`의 `mock_responses`를 도구 결과로 돌려줘야 채점할 수 있어요. 지원이 어려우면 해당 문항은 '미실행'으로 표시해 주세요.
3. 도구 이름은 기획서 §6 예시를 따랐고, 11/20 API 설계 문서에서 최종 확정해요.
4. 강사님 문서에 2팀 주제가 '학교 안내'로 적혀 있는데, 유치온(유치원 학부모 소통·민원)으로 바뀌었어요.
