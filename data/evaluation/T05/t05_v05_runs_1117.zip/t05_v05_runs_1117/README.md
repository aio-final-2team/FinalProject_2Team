# T05 팀 자체 30문항 v0.5 실행 기록 (2026-11-17)

팀 자체 30문항 v0.5를 gpt-6-luna·gpt-5.4-mini로 한 번씩 돌린 원래 기록입니다. 모델에게 보낸 요청과 받은 응답이 문항마다 그대로 남아 있습니다. 실행: 영민, 팀 OpenAI 키.

## 결과

| 실행 | 요청 모델 | 응답에 찍힌 모델 ID | PASS / 30 | FAIL | ERROR | 평균 응답 시간 | 토큰(입력·출력) | 실행 시각(UTC) |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| `results/20261117T083234Z-gpt-6-luna-full` | gpt-6-luna | gpt-6-luna | 19 | 11 | 0 | 3.46초 | 29,387 · 4,197 | 2026-11-17 08:32 (KST 17:32) |
| `results/20261117T083234Z-gpt-5.4-mini-full` | gpt-5.4-mini | gpt-5.4-mini-2026-03-17 | 19 | 11 | 0 | 2.24초 | 27,356 · 2,868 | 2026-11-17 08:32 (KST 17:32) |

- 실패 이유 문항별 분석: `results/ANALYSIS-20261117.md`, 두 모델 비교표: `results/COMPARE-20261117T083424Z.md`, 공유용 보고서: `REPORT.md`
- `*-partial3`은 본 실행 전 3문항 맛보기(연결 확인용)라 점수 비교에 쓰지 않습니다.

## 실행 조건

- OpenAI Responses API(`store=false`), `tool_choice=auto`, 온도·추론 기본값, 시스템 프롬프트 판 `p1`(원문은 각 `run.json`)
- 함수 정의에 `strict`를 적지 않음 → OpenAI 기본값(켬)으로 실행. 태웅님 13개 모델 반복 실행(`t05_model_runs_1117.zip`, `strict: false`)과 조건이 다릅니다.
- 채점: `run_v05.py`(팀 재구현). 함수 이름·인자·호출 수·순서를 자동 채점하고, `query`·`summary`·`topic`과 문의 카드의 분류 칸은 사람 검토로 둠. 오류 모의 응답 뒤 1번 재시도 허용
- 실행한 문항 파일: `team30_v05_run_spec.json` (sha256 `9e3acccf…`, 각 `run.json`의 `spec_sha256`과 같음)

## develop의 v0.5와 다른 점

develop의 `Docs/Step2/2팀_유치온_자체평가_30문항.json`(PR #235 머지본, sha256 `f88e88be…`)과 비교하면 **`create_card`의 인자 이름 `category`가 `topic_key`로 바뀐 것 하나**만 다릅니다(계약표 이름 맞춤). 값 목록·정답 호출·모의 응답의 내용은 같고, 해당 문항은 YC-N09·N10·M02·M05·M06·M07·F03·F04입니다. 그래서 점수는 같은 문항 기준으로 볼 수 있지만, 문항 파일 해시는 다릅니다.

## 다시 돌리기

```
OPENAI_API_KEY=... python3 run_v05.py run --mode openai --model gpt-6-luna
python3 run_v05.py self-test   # 키 없이 채점기만 확인
```
API 키는 이 묶음에 들어 있지 않습니다.
