# T05 모델 비교 실행 기록 (2026-11-17)

기획서 11.1 "4차 결정과 모델 비교 근거"에 적힌 점수·응답 시간·비용의 원래 기록입니다. 모델에게 실제로 보낸 요청과 받은 응답이 문항마다 그대로 남아 있습니다. 기존 `assets/T05/eval_bfcl.zip`(영민님 실행기)과는 다른 실행입니다.

## 폴더 세 개

| 폴더 | 무엇을 돌렸나 | 언제 | 결과 |
| --- | --- | --- | --- |
| `1_bfcl_screen` | BFCL 원본 30문항, gpt-6-luna·gpt-5.4-mini 각 1회 | 11/17 17:47 | luna 24/30, mini 21/30 |
| `2_team30_v03` | 팀 자체 30문항 v0.3(PR #235), 두 모델 각 1회 | 11/17 17:52 | luna 21/30, mini 12/30 |
| `3_repeats_13models` | 위 두 실행기로 GPT 13개 모델 반복 | 11/17 22:03~22:23 | `summary.csv` |

`summary.csv`는 `3_repeats_13models/runs`의 반복 실행과 1·2번 폴더의 오후 실행을 모델별로 합친 표입니다. 그래서 luna와 mini는 6회, 나머지 모델은 팀 문항 3회·BFCL 2회입니다.

## 공통 실행 조건

- OpenAI Responses API, 팀 OpenAI 키, 실행한 사람 태웅
- `tool_choice=auto`, 함수 정의 `strict: false`, 온도·추론은 기본값
- BFCL 문항: 강사님 BFCL-PREPARE 고정 30문항. 문항 ID와 BFCL 버전(revision 61fc060)은 `1_bfcl_screen/raw-data/SOURCE-MANIFEST.json`
- 팀 문항: `2_team30_v03/team30_v03.json`. 시스템 프롬프트는 문항 JSON의 `context`(오늘 날짜·학부모·볼 수 있는 아이와 교사)만 문장으로 바꾼 한 줄이고, 원문은 각 실행의 `run.json`에 있음

`eval_bfcl.zip`의 21:21과 1번 폴더의 24:21이 다른 이유는 `strict` 설정입니다. zip 실행기는 `strict`를 적지 않아 OpenAI 기본값(켬)으로 돌았고, 그러면 선택 인자까지 필수가 되어 두 문항을 틀립니다.

## 실행 하나에 들어 있는 파일

| 파일 | 내용 |
| --- | --- |
| `RESULTS.csv` | 문항별 통과 여부, 모델이 부른 도구와 인자, 응답 시간(`latency_s`, 초) |
| `run.json` | 요청한 모델 ID, 응답에 찍힌 실제 모델 ID, 실행 시각, 통과 수 합계(`totals`). 팀 문항 실행은 시스템 프롬프트 원문도 |
| `usage.json` | 입력·출력 토큰 수(3번 폴더 반복 실행에만 있음) |
| `cases/`(팀 문항) 또는 `<문항ID>-request.json`·`-raw.json`·`-result.json`(BFCL) | 문항마다 보낸 요청, 받은 응답 원문, 채점 결과 |

## summary.csv 칸

| 칸 | 뜻 |
| --- | --- |
| `team30_lenient` | 팀 30문항 조회 허용 채점 평균. 정답 호출은 다 있어야 하고, 조회 도구(`search_documents`·`get_memory`·`find_consult_slots`)를 더 부른 건 봐줌. 쓰기 도구를 더 부르면 오답 |
| `team30_strict` | 팀 30문항 엄격 채점 평균. 정답지와 호출 개수·인자가 똑같아야 통과 |
| `sec_per_item` | 팀 30문항 한 문항 평균 응답 시간(초) |
| `bfcl_mean` | BFCL 30문항 평균 |
| `monthly_usd_per_kindergarten` | 원아 100명 유치원 한 달(질문 1,100건) 모델 요금 추정, 달러. 질문 1건에 모델 4번 호출, 입력 3,000·출력 150토큰 가정, 11/17 OpenAI 가격표 |

## 다시 돌리기

팀 문항 실행기는 문항 파일을 바꿔 돌릴 수 있습니다. API 키는 환경 변수로만 넣고 파일·커밋에 남기지 않습니다.

```bash
cd 2_team30_v03
OPENAI_API_KEY=팀키 python3 run_team30.py --model gpt-6-luna --spec 새_문항.json
OPENAI_API_KEY=팀키 python3 run_team30.py --model gpt-5.4-mini --spec 새_문항.json
```

결과는 `2_team30_v03/results/<시각>-<모델>-full/`에 생깁니다. 통과 수는 `run.json`의 `totals.PASS`, 문항별 결과와 응답 시간은 `RESULTS.csv`에서 봅니다.
