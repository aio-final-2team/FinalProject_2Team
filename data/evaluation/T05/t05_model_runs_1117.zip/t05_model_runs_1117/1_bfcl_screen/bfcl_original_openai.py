"""BFCL 원본 30문항 부분 집합 평가 — OpenAI Responses API 어댑터판.

강사님 BFCL-PREPARE.md 9~13절 명세(고정 revision·30개 ID·변환 규칙·교육용 채점 규칙)를 그대로 따른다.
강사님 실행기 bfcl_original.py는 수강생 레포에 파일이 없어(문서만 배포) 명세대로 다시 구현했고,
모델 호출 부분만 Gemini REST → OpenAI Responses API로 바꿨다. 표준 라이브러리만 쓴다.

사용:
  python3 bfcl_original_openai.py prepare
  python3 bfcl_original_openai.py self-test
  OPENAI_API_KEY=... python3 bfcl_original_openai.py run --model gpt-6-luna [--smoke]
"""
import argparse, csv, hashlib, json, os, re, sys, time, urllib.error, urllib.request
from datetime import datetime, timezone
from pathlib import Path

HERE = Path(__file__).resolve().parent
RAW = HERE / "raw-data"
REV = "61fc0608cfd831fcfbbaa676ebdfef0ed963eeda"
BASE = f"https://huggingface.co/datasets/gorilla-llm/Berkeley-Function-Calling-Leaderboard/resolve/{REV}/"
FILES = {  # 경로: (건수, SHA-256) — 팀 BFCL-USE-PLAN.md 3~4절 값
    "BFCL_v3_simple.json": (400, "fbc37b2ad252bf9af985582e0e07b456173fe627d957491472ea9cef5fb83158"),
    "BFCL_v3_multiple.json": (200, "aef168155ebd74b7ac2401198b201343bc7d16d7a3d7e0d4e6d8ee82c6969b2a"),
    "BFCL_v3_irrelevance.json": (240, "975f51c51f688649fd190078efd87081241e0a326f9114a2ea3c1ca2440d8690"),
    "possible_answer/BFCL_v3_simple.json": (400, "2911a2bc00df82c4f999ffa64fedb0164cb88e96212ffa5972087eb91fd496ee"),
    "possible_answer/BFCL_v3_multiple.json": (200, "244e00ce9395df948bcafc7bee64e8f9c87ef70887587d83cae45b13699f3047"),
}
IDS = {
    "simple": "simple_149 simple_170 simple_181 simple_221 simple_242 simple_257 simple_302 simple_309 simple_367 simple_399".split(),
    "multiple": "multiple_123 multiple_134 multiple_14 multiple_16 multiple_170 multiple_178 multiple_20 multiple_24 multiple_53 multiple_69".split(),
    "irrelevance": "irrelevance_134 irrelevance_16 irrelevance_170 irrelevance_178 irrelevance_20 irrelevance_203 irrelevance_32 irrelevance_68 irrelevance_86 irrelevance_87".split(),
}
SMOKE = ["simple_149", "multiple_123", "irrelevance_134"]
GRADER = "educational-bfcl-v3-subset-1 (BFCL-PREPARE.md 12절 명세 재구현)"
OMIT = ""  # 정답 목록의 '생략 허용' 표지


def read_jsonl(p):
    return [json.loads(l) for l in p.read_text(encoding="utf-8").splitlines() if l.strip()]


def prepare():
    manifest = {"dataset": "gorilla-llm/Berkeley-Function-Calling-Leaderboard", "revision": REV, "license": "Apache-2.0", "files": {}}
    for name, (count, sha) in FILES.items():
        p = RAW / name
        if not p.exists():
            p.parent.mkdir(parents=True, exist_ok=True)
            urllib.request.urlretrieve(BASE + name, p)
        got_sha = hashlib.sha256(p.read_bytes()).hexdigest()
        got_n = len(read_jsonl(p))
        if got_sha != sha or got_n != count:
            sys.exit(f"원본 불일치로 중단: {name} sha={got_sha} n={got_n}")
        manifest["files"][name] = {"url": BASE + name, "bytes": p.stat().st_size, "count": got_n, "sha256": got_sha}
    q, a = {}, {}
    for c in IDS:
        q.update({r["id"]: r for r in read_jsonl(RAW / f"BFCL_v3_{c}.json")})
    for c in ("simple", "multiple"):
        a.update({r["id"]: r for r in read_jsonl(RAW / f"possible_answer/BFCL_v3_{c}.json")})
    all_ids = [i for c in IDS for i in IDS[c]]
    if len(all_ids) != 30 or len(set(all_ids)) != 30 or any(not i.startswith(c + "_") for c in IDS for i in IDS[c]):
        sys.exit("고정 ID 30개 검사 실패")
    cases = []
    for c, ids in IDS.items():
        for i in ids:
            cases.append({"id": i, "category": c, "question": q[i]["question"], "function": q[i]["function"],
                          "ground_truth": a[i]["ground_truth"] if c != "irrelevance" else []})
    manifest["selected_ids"] = all_ids
    (RAW / "SOURCE-MANIFEST.json").write_text(json.dumps(manifest, ensure_ascii=False, indent=2), encoding="utf-8")
    (RAW / "SUBSET.json").write_text(json.dumps(cases, ensure_ascii=False, indent=2), encoding="utf-8")
    print(f"Prepared {len(cases)} cases (revision {REV[:12]}); no model called")
    return cases


def load_cases():
    p = RAW / "SUBSET.json"
    return json.loads(p.read_text(encoding="utf-8")) if p.exists() else prepare()


# ── 스키마 변환 (BFCL → OpenAI 함수 도구) ─────────────────────────────
TYPE_MAP = {"dict": "object", "float": "number", "tuple": "array", "integer": "integer", "string": "string",
            "boolean": "boolean", "array": "array", "object": "object", "number": "number"}


class AdapterError(Exception):
    pass


def conv_schema(s):
    if not isinstance(s, dict):
        raise AdapterError(f"스키마가 dict가 아님: {s!r}")
    out = {}
    for k, v in s.items():
        if k == "optional":
            continue  # 공급자 필드에서 제외(required는 원본대로)
        if k == "type":
            if v == "any":
                continue
            if v not in TYPE_MAP:
                raise AdapterError(f"지원하지 않는 타입: {v}")
            out["type"] = TYPE_MAP[v]
        elif k == "properties":
            out["properties"] = {pk: conv_schema(pv) for pk, pv in v.items()}
        elif k == "items":
            out["items"] = conv_schema(v)
        else:
            out[k] = v
    return out


def tools_for(functions):
    alias, tools, used = {}, [], set()
    for f in functions:
        a = re.sub(r"[^A-Za-z0-9_-]", "_", f["name"])[:64]
        base, n = a, 2
        while a in used:
            a = f"{base[:60]}_{n}"; n += 1
        used.add(a); alias[a] = f["name"]
        tools.append({"type": "function", "name": a, "description": f.get("description", ""),
                      "parameters": conv_schema(f["parameters"]), "strict": False})
    return tools, alias


# ── 교육용 채점 ───────────────────────────────────────────────────────
def type_ok(v, t):
    if t in (None, "any"):
        return True
    if t == "string": return isinstance(v, str)
    if t == "boolean": return isinstance(v, bool)
    if t == "integer": return isinstance(v, int) and not isinstance(v, bool)
    if t == "float": return isinstance(v, (int, float)) and not isinstance(v, bool)
    if t in ("array", "tuple"): return isinstance(v, list)
    if t == "dict": return isinstance(v, dict)
    return False


def same(v, c, schema):
    """값 v가 후보 c와 같은가. 배열 순서 유지, 문자열 정확 비교, true≠1."""
    t = (schema or {}).get("type")
    if isinstance(c, dict):
        if not isinstance(v, dict): return False
        props = (schema or {}).get("properties", {})
        if set(v) - set(c): return False
        for k, allowed in c.items():
            if k not in v:
                if OMIT not in allowed: return False
                continue
            if not type_ok(v[k], props.get(k, {}).get("type")): return False
            if not any(same(v[k], cc, props.get(k)) for cc in allowed if cc != OMIT): return False
        return True
    if isinstance(c, list):
        if not isinstance(v, list) or len(v) != len(c): return False
        item = (schema or {}).get("items")
        return all(same(x, y, item) for x, y in zip(v, c))
    if isinstance(c, bool) or isinstance(v, bool):
        return isinstance(c, bool) and isinstance(v, bool) and c == v
    if isinstance(c, (int, float)) and isinstance(v, (int, float)):
        if t == "integer" and not isinstance(v, int): return False
        return v == c
    return type(v) is type(c) and v == c


def grade(case, calls):
    """calls: [(원본 함수 이름, 인자 dict)]. (판정, 이유) 반환."""
    if case["category"] == "irrelevance":
        return ("PASS", "호출 0개") if not calls else ("FAIL", f"호출 {len(calls)}개(비호출이어야 함)")
    if len(calls) != 1:
        return "FAIL", f"호출 {len(calls)}개(정확히 1개여야 함)"
    name, args = calls[0]
    (gt_name, gt_args), = case["ground_truth"][0].items()
    if name != gt_name:
        return "FAIL", f"함수 다름: {name} (정답 {gt_name})"
    fn = next(f for f in case["function"] if f["name"] == gt_name)
    props, req = fn["parameters"].get("properties", {}), fn["parameters"].get("required", [])
    for r in req:
        if r not in args: return "FAIL", f"필수 인자 없음: {r}"
    for k in args:
        if k not in gt_args: return "FAIL", f"추가 인자: {k}"
    for k, allowed in gt_args.items():
        sch = props.get(k, {})
        if k not in args:
            if OMIT in allowed and k not in req: continue
            return "FAIL", f"인자 생략 불가: {k}"
        v = args[k]
        if not type_ok(v, sch.get("type")): return "FAIL", f"타입 다름: {k}={v!r} (원본 {sch.get('type')})"
        if "enum" in sch and v not in sch["enum"]: return "FAIL", f"enum 밖: {k}={v!r}"
        if not any(same(v, c, sch) for c in allowed if c != OMIT):
            return "FAIL", f"값 다름: {k}={json.dumps(v, ensure_ascii=False)} (허용 {json.dumps([c for c in allowed if c != OMIT], ensure_ascii=False)[:200]})"
    return "PASS", "함수·인자 일치"


def self_test(cases):
    for c in cases:
        if c["category"] == "irrelevance":
            assert grade(c, [])[0] == "PASS" and grade(c, [("x", {})])[0] == "FAIL"
            continue
        (fname, gargs), = c["ground_truth"][0].items()
        args = {k: next(x for x in v if x != OMIT) for k, v in gargs.items() if any(x != OMIT for x in v)}
        g = grade(c, [(fname, args)])
        assert g[0] == "PASS", (c["id"], g)
        assert grade(c, [(fname + "_wrong", args)])[0] == "FAIL"
    print(f"Offline self-test passed: {len(cases)} original cases; no model called")


# ── 모델 호출 (OpenAI Responses API) ──────────────────────────────────
def call_openai(model, messages, tools, key):
    body = {"model": model, "input": messages, "tools": tools, "tool_choice": "auto", "store": False}
    req = urllib.request.Request("https://api.openai.com/v1/responses", data=json.dumps(body).encode(),
                                 headers={"Authorization": f"Bearer {key}", "Content-Type": "application/json"})
    t0 = time.time()
    try:
        with urllib.request.urlopen(req, timeout=180) as r:
            return body, json.loads(r.read()), None, time.time() - t0
    except urllib.error.HTTPError as e:
        return body, None, f"HTTP {e.code}: {e.read().decode(errors='replace')[:500]}", time.time() - t0
    except Exception as e:  # 네트워크 등
        return body, None, f"{type(e).__name__}: {e}", time.time() - t0


def run(model, smoke):
    key = os.environ.get("OPENAI_API_KEY")
    if not key:
        sys.exit("OPENAI_API_KEY가 없음")
    cases = load_cases()
    if smoke:
        cases = [c for c in cases if c["id"] in SMOKE]
    run_id = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ") + f"-{model}-{'smoke' if smoke else 'full'}"
    out = HERE / "results" / f"{run_id}-bfcl-original"
    out.mkdir(parents=True)
    rows, resp_models = [], set()
    for n, c in enumerate(cases, 1):
        rec = {"id": c["id"], "category": c["category"]}
        try:
            tools, alias = tools_for(c["function"])
        except AdapterError as e:
            rec.update(verdict="ERROR", reason=f"adapter_error: {e}", calls=[], latency_s=0)
            rows.append(rec); print(f"[{n}/{len(cases)}] {c['id']} ERROR"); continue
        messages = [m for turn in c["question"] for m in turn]
        body, raw, err, dt = call_openai(model, messages, tools, key)
        (out / f"{c['id']}-request.json").write_text(json.dumps({"request": body, "alias": alias}, ensure_ascii=False, indent=2), encoding="utf-8")
        rec["latency_s"] = round(dt, 2)
        if err:
            rec.update(verdict="ERROR", reason=f"api_error: {err}", calls=[])
        else:
            (out / f"{c['id']}-raw.json").write_text(json.dumps(raw, ensure_ascii=False, indent=2), encoding="utf-8")
            resp_models.add(raw.get("model"))
            outputs = raw.get("output") or []
            calls, bad = [], None
            for o in outputs:
                if o.get("type") == "function_call":
                    try:
                        calls.append((alias.get(o["name"], o["name"]), json.loads(o.get("arguments") or "{}")))
                    except json.JSONDecodeError as e:
                        bad = f"parse_error: {e}"
            text = any(o.get("type") == "message" for o in outputs)
            rec["usage"] = raw.get("usage")
            rec["response_model"] = raw.get("model")
            rec["response_id"] = raw.get("id")
            rec["calls"] = [{"name": a, "args": b} for a, b in calls]
            if bad:
                rec.update(verdict="ERROR", reason=bad)
            elif raw.get("status") != "completed":
                rec.update(verdict="ERROR", reason=f"status={raw.get('status')}")
            elif not calls and not text:
                rec.update(verdict="ERROR", reason="빈 응답(호출·문장 없음)")
            else:
                v, why = grade(c, calls)
                rec.update(verdict=v, reason=why)
        (out / f"{c['id']}-result.json").write_text(json.dumps({**rec, "ground_truth": c["ground_truth"]}, ensure_ascii=False, indent=2), encoding="utf-8")
        rows.append(rec)
        print(f"[{n}/{len(cases)}] {c['id']} {rec['verdict']}")
    with open(out / "RESULTS.csv", "w", newline="", encoding="utf-8") as f:
        w = csv.writer(f)
        w.writerow(["id", "category", "verdict", "reason", "calls", "latency_s", "response_model", "response_id"])
        for r in rows:
            w.writerow([r["id"], r["category"], r["verdict"], r["reason"], json.dumps(r.get("calls", []), ensure_ascii=False), r.get("latency_s"), r.get("response_model"), r.get("response_id")])
    tot = {k: sum(r["verdict"] == k for r in rows) for k in ("PASS", "FAIL", "ERROR")}
    by = {c: {k: sum(r["verdict"] == k and r["category"] == c for r in rows) for k in ("PASS", "FAIL", "ERROR")} for c in IDS}
    meta = {"result_kind": "bfcl_subset", "runner": "team_run (OpenAI 어댑터)", "run_mode": "smoke_3" if smoke else "full_30",
            "run_id": run_id, "requested_model": model, "response_models": sorted(m for m in resp_models if m),
            "api": "OpenAI Responses API, tool_choice=auto, 시스템 프롬프트 없음, 온도·추론 설정 기본값", "grader": GRADER,
            "code_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(), "revision": REV,
            "selected": len(rows), "ids": [r["id"] for r in rows], "totals": tot, "by_category": by,
            "started_utc": run_id[:16], "finished_utc": datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")}
    (out / "run.json").write_text(json.dumps(meta, ensure_ascii=False, indent=2), encoding="utf-8")
    lat = [r["latency_s"] for r in rows if r.get("latency_s")]
    md = [f"# BFCL 원본 30문항 부분 집합 평가 — {model}", "",
          f"- run_id: `{run_id}` · 모드: {meta['run_mode']} · 응답 모델 ID: {', '.join(meta['response_models'])}",
          f"- 원본: BFCL v3 revision `{REV}` · 채점: {GRADER}", f"- 결과: PASS {tot['PASS']} · FAIL {tot['FAIL']} · ERROR {tot['ERROR']} / {len(rows)}",
          f"- 평균 응답 시간: {sum(lat)/len(lat):.2f}초" if lat else "", "", "| 범주 | PASS | FAIL | ERROR |", "|---|---:|---:|---:|"]
    md += [f"| {c} | {by[c]['PASS']} | {by[c]['FAIL']} | {by[c]['ERROR']} |" for c in IDS]
    md += ["", "| ID | 판정 | 이유 |", "|---|---|---|"] + [f"| {r['id']} | {r['verdict']} | {r['reason']} |" for r in rows]
    md += ["", "공식 BFCL 점수·리더보드 점수가 아니다. 교육용 채점기로 본 30문항 표본의 관측 결과다."]
    (out / "SUMMARY.md").write_text("\n".join(md) + "\n", encoding="utf-8")
    print(f"PASS {tot['PASS']} FAIL {tot['FAIL']} ERROR {tot['ERROR']} → {out}")


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("cmd", nargs="?", default="run", choices=["prepare", "self-test", "run"])
    ap.add_argument("--model")
    ap.add_argument("--smoke", action="store_true")
    a = ap.parse_args()
    if a.cmd == "prepare":
        prepare()
    elif a.cmd == "self-test":
        self_test(load_cases())
    else:
        if not a.model:
            sys.exit("--model 필요")
        run(a.model, a.smoke)
