# BFCL 원본 30문항 부분 집합 평가 — gpt-6-luna

- run_id: `20261117T130315Z-gpt-6-luna-full` · 모드: full_30 · 응답 모델 ID: gpt-6-luna
- 원본: BFCL v3 revision `61fc0608cfd831fcfbbaa676ebdfef0ed963eeda` · 채점: educational-bfcl-v3-subset-1 (BFCL-PREPARE.md 12절 명세 재구현)
- 결과: PASS 22 · FAIL 8 · ERROR 0 / 30
- 평균 응답 시간: 1.80초

| 범주 | PASS | FAIL | ERROR |
|---|---:|---:|---:|
| simple | 6 | 4 | 0 |
| multiple | 8 | 2 | 0 |
| irrelevance | 8 | 2 | 0 |

| ID | 판정 | 이유 |
|---|---|---|
| simple_149 | FAIL | 호출 2개(정확히 1개여야 함) |
| simple_170 | PASS | 함수·인자 일치 |
| simple_181 | PASS | 함수·인자 일치 |
| simple_221 | PASS | 함수·인자 일치 |
| simple_242 | FAIL | 값 다름: discovery="the theory of evolution" (허용 ["Theory of Evolution", "theory of evolution"]) |
| simple_257 | PASS | 함수·인자 일치 |
| simple_302 | PASS | 함수·인자 일치 |
| simple_309 | PASS | 함수·인자 일치 |
| simple_367 | FAIL | 값 다름: recipe_type="brownies" (허용 ["dessert"]) |
| simple_399 | FAIL | 값 다름: rating=5 (허용 [4]) |
| multiple_123 | FAIL | 값 다름: round_to=4 (허용 [2]) |
| multiple_134 | PASS | 함수·인자 일치 |
| multiple_14 | PASS | 함수·인자 일치 |
| multiple_16 | PASS | 함수·인자 일치 |
| multiple_170 | PASS | 함수·인자 일치 |
| multiple_178 | PASS | 함수·인자 일치 |
| multiple_20 | PASS | 함수·인자 일치 |
| multiple_24 | PASS | 함수·인자 일치 |
| multiple_53 | FAIL | 호출 2개(정확히 1개여야 함) |
| multiple_69 | PASS | 함수·인자 일치 |
| irrelevance_134 | PASS | 호출 0개 |
| irrelevance_16 | PASS | 호출 0개 |
| irrelevance_170 | PASS | 호출 0개 |
| irrelevance_178 | PASS | 호출 0개 |
| irrelevance_20 | PASS | 호출 0개 |
| irrelevance_203 | FAIL | 호출 1개(비호출이어야 함) |
| irrelevance_32 | PASS | 호출 0개 |
| irrelevance_68 | PASS | 호출 0개 |
| irrelevance_86 | FAIL | 호출 1개(비호출이어야 함) |
| irrelevance_87 | PASS | 호출 0개 |

공식 BFCL 점수·리더보드 점수가 아니다. 교육용 채점기로 본 30문항 표본의 관측 결과다.
