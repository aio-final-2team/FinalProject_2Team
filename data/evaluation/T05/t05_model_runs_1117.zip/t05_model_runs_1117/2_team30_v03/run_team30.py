"""유치온 팀 자체평가 30문항(인혜 PR #235, v0.3) 실행기 — OpenAI Responses API.

문항 JSON의 tools·context·items를 그대로 쓴다. 채점은 문항 md 5절:
자동 = 함수 이름, 인자 값(summary 제외), 호출 개수·순서 / 사람 = 응답 문장·summary·'하면 안 되는 것'.
- single·parallel·none: 한 번 호출. parallel은 순서 무관, none은 호출 0개 + 문장이 있어야 함(문장 내용은 사람 검토)
- sequential: 1단계 호출에 문항의 가짜 결과를 돌려준 뒤 2단계 호출까지 순서대로 비교
- single_with_followup_answer: 1단계 호출 → 가짜 결과 → 2단계는 추가 호출 없이 답해야 함
사용: OPENAI_API_KEY=... python3 run_team30.py --model gpt-6-luna [--spec 문항.json] [--only YC-N01,YC-M04]
(--spec을 안 주면 같은 폴더의 team30_v03.json)
"""
import argparse, csv, hashlib, json, os, sys, time, urllib.error, urllib.request
from datetime import datetime, timezone
from pathlib import Path

HERE = Path(__file__).resolve().parent
SPEC = HERE / "team30_v03.json"


def system_prompt(ctx):
    return (f"당신은 {ctx['kindergarten_name']}(유치원 ID {ctx['kindergarten_id']})의 학부모 안내 도우미입니다. "
            f"오늘은 {ctx['today']}({ctx['day_of_week']})이고 내일은 {ctx['tomorrow']}입니다. "
            f"지금 대화하는 사람은 학부모이며, 볼 수 있는 아이는 {', '.join(ctx['allowed_child_ids'])}, "
            f"볼 수 있는 교사는 {', '.join(ctx['allowed_teacher_ids'])}(우리 반 담임)뿐입니다. "
            "필요하면 제공된 도구를 사용하세요.")


def to_responses_tool(t):
    f = t["function"]
    return {"type": "function", "name": f["name"], "description": f.get("description", ""),
            "parameters": f["parameters"], "strict": False}


def call(model, body_extra, key):
    body = {"model": model, "store": True, **body_extra}
    req = urllib.request.Request("https://api.openai.com/v1/responses", data=json.dumps(body, ensure_ascii=False).encode(),
                                 headers={"Authorization": f"Bearer {key}", "Content-Type": "application/json"})
    t0 = time.time()
    try:
        with urllib.request.urlopen(req, timeout=180) as r:
            return body, json.loads(r.read()), None, time.time() - t0
    except urllib.error.HTTPError as e:
        return body, None, f"HTTP {e.code}: {e.read().decode(errors='replace')[:400]}", time.time() - t0
    except Exception as e:
        return body, None, f"{type(e).__name__}: {e}", time.time() - t0


def parse(raw):
    calls, text = [], ""
    for o in raw.get("output") or []:
        if o.get("type") == "function_call":
            calls.append({"name": o["name"], "arguments": json.loads(o.get("arguments") or "{}"), "call_id": o["call_id"]})
        elif o.get("type") == "message":
            text += "".join(c.get("text", "") for c in o.get("content", []) if c.get("type") == "output_text")
    return calls, text


def norm(c):
    return (c["name"], json.dumps({k: v for k, v in c["arguments"].items() if k != "summary"}, sort_keys=True, ensure_ascii=False))


def match_list(got, exp, ordered):
    g, e = [norm(c) for c in got], [norm(c) for c in exp]
    return g == e if ordered else sorted(g) == sorted(e)


def explain(got, exp):
    g = [norm(c) for c in got]; e = [norm(c) for c in exp]
    if len(g) != len(e):
        return f"호출 {len(g)}개(기대 {len(e)}개): {[x[0] for x in g]}"
    for a, b in zip(sorted(g), sorted(e)):
        if a != b:
            return f"다름: {a[0]} {a[1]} (기대 {b[0]} {b[1]})"
    return "순서 다름"


def run_item(model, item, tools, sysmsg, key, out):
    rec = {"id": item["id"], "type": item["type"], "order": item["execution_order"], "steps": []}
    inp = [{"role": "system", "content": sysmsg}, {"role": "user", "content": item["question"]}]
    body, raw, err, dt = call(model, {"input": inp, "tools": tools, "tool_choice": "auto"}, key)
    lat = dt
    if err:
        return {**rec, "verdict": "ERROR", "reason": err, "latency_s": round(lat, 2)}
    c1, t1 = parse(raw)
    rec["steps"].append({"request": body, "response": raw})
    rec["response_model"] = raw.get("model")
    exp, order = item["expected_calls"], item["execution_order"]
    all_calls, final_text = list(c1), t1
    if item["stage"] == "stage_2_mock_followup" and c1:
        mocks = item.get("mock_tool_outputs") or {}
        outs = [{"type": "function_call_output", "call_id": c["call_id"],
                 "output": json.dumps(mocks.get(c["name"], {"result": "(이 도구의 가짜 결과는 문항에 없음)"}), ensure_ascii=False)} for c in c1]
        body2, raw2, err2, dt2 = call(model, {"previous_response_id": raw["id"], "input": outs, "tools": tools, "tool_choice": "auto"}, key)
        lat += dt2
        if err2:
            return {**rec, "verdict": "ERROR", "reason": "2단계 " + err2, "latency_s": round(lat, 2)}
        c2, t2 = parse(raw2)
        rec["steps"].append({"request": body2, "response": raw2})
        all_calls += c2; final_text = t2 or final_text
    else:
        c2 = []
    rec["calls"] = [{"name": c["name"], "arguments": c["arguments"]} for c in all_calls]
    rec["final_text"] = final_text
    rec["latency_s"] = round(lat, 2)
    if order == "none":
        ok = not all_calls and bool(final_text.strip())
        why = "호출 0개, 문장 있음(문장 내용은 사람 검토)" if ok else (f"호출 {len(all_calls)}개(0개여야 함)" if all_calls else "빈 응답")
    elif order == "sequential":
        ok = match_list(c1, exp[:1], True) and match_list(c2, exp[1:], True)
        why = "1→2단계 호출 일치" if ok else f"1단계 {[norm(c) for c in c1]} / 2단계 {[norm(c) for c in c2]}"
    elif order == "single_with_followup_answer":
        ok = match_list(c1, exp, True) and not c2 and bool(final_text.strip())
        why = "호출 일치, 가짜 결과 받고 답함" if ok else (explain(c1, exp) if not match_list(c1, exp, True) else ("2단계에서 추가 호출" if c2 else "2단계 빈 응답"))
    else:  # single, parallel
        ok = match_list(all_calls, exp, order != "parallel")
        why = "호출 일치" if ok else explain(all_calls, exp)
    rec["verdict"], rec["reason"] = ("PASS" if ok else "FAIL"), why
    return rec


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--model", required=True)
    ap.add_argument("--only")
    ap.add_argument("--spec", type=Path, default=SPEC, help="문항 JSON (기본 team30_v03.json)")
    a = ap.parse_args()
    key = os.environ.get("OPENAI_API_KEY") or sys.exit("OPENAI_API_KEY가 없음")
    spec = json.loads(a.spec.read_text(encoding="utf-8"))
    items = spec["items"]
    if a.only:
        keep = set(a.only.split(",")); items = [i for i in items if i["id"] in keep]
    tools = [to_responses_tool(t) for t in spec["tools"]]
    sysmsg = system_prompt(spec["context"])
    run_id = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ") + f"-{a.model}-{'partial' if a.only else 'full'}"
    out = HERE / "results" / run_id
    (out / "cases").mkdir(parents=True)
    rows = []
    for n, it in enumerate(items, 1):
        r = run_item(a.model, it, tools, sysmsg, key, out)
        (out / "cases" / f"{it['id']}.json").write_text(json.dumps({**r, "expected_calls": it["expected_calls"],
            "expected_response": it["expected_response"], "forbidden_behaviors": it["forbidden_behaviors"]}, ensure_ascii=False, indent=2), encoding="utf-8")
        rows.append(r); print(f"[{n}/{len(items)}] {it['id']} {r['verdict']}")
    with open(out / "RESULTS.csv", "w", newline="", encoding="utf-8") as f:
        w = csv.writer(f)
        w.writerow(["id", "type", "verdict", "reason", "calls", "final_text", "latency_s", "response_model"])
        for r in rows:
            w.writerow([r["id"], r["type"], r["verdict"], r["reason"], json.dumps(r.get("calls", []), ensure_ascii=False), r.get("final_text", ""), r.get("latency_s"), r.get("response_model")])
    tot = {k: sum(r["verdict"] == k for r in rows) for k in ("PASS", "FAIL", "ERROR")}
    by = {}
    for r in rows:
        by.setdefault(r["type"], {"PASS": 0, "FAIL": 0, "ERROR": 0})[r["verdict"]] += 1
    meta = {"result_kind": "team_domain", "dataset": spec["dataset_name"], "version": spec["version"], "run_id": run_id,
            "requested_model": a.model, "response_models": sorted({r.get("response_model") for r in rows if r.get("response_model")}),
            "api": "OpenAI Responses API, tool_choice=auto, 2단계는 previous_response_id, 온도·추론 기본값", "system_prompt": sysmsg,
            "spec_file": a.spec.name, "spec_sha256": hashlib.sha256(a.spec.read_bytes()).hexdigest(), "code_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
            "executed": f"{len(rows)}/30", "totals": tot, "by_type": by}
    (out / "run.json").write_text(json.dumps(meta, ensure_ascii=False, indent=2), encoding="utf-8")
    print(f"PASS {tot['PASS']} FAIL {tot['FAIL']} ERROR {tot['ERROR']} ({len(rows)}/30) → {out}")


if __name__ == "__main__":
    main()
