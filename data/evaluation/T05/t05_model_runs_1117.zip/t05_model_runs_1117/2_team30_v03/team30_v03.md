# 유치온 자체 평가 30문항 (초안 v0.3)

- **목적**: 강사님 문서(`BFCL-PREPARE`) 14절 및 WBS `T06`(이슈 `#163`, [유치온_기획서_1116.md](../Step1/유치온_기획서_1116.md))의 **팀 자체 30문항**을 유치온 MVP 핵심 흐름(**안내 문의·상담·민원**)에 맞춰 설계
- **결과 구분**: `team_domain` (BFCL 원본 30문항 `bfcl_subset`과 **별도 표·별도 분모**로 보고 — `NFR-09`, `AC-07`)
- **상태**: 문항·기대값 초안 v0.3 확정 (아직 모델로 실행하지 않음. 버전 변경 시 `v0.4`로 올림)
- **비교 대상 모델 (`D10`, `D21`, `T05`)**:
  - 후보 모델 ID: `gpt-6-luna`, `gpt-5.4-mini` (11/18 `T05`에서 두 실제 모델 ID로 호출·비교한 뒤 확정)
  - 제공자(Provider): OpenAI 계열 추정이나 기획서에 제공자명이 명시되어 있지 않아 11/18 `T05` 실제 API 호출 및 반환 모델 ID로 최종 확인·기록함
- **v0.2 → v0.3 주요 변경 내역**:
  1. **평가 범위 정합화 (`§2.3`, `AC-07`, `T06`)**: 최종(`STEP 4`) 기능인 통학버스·사진·알림장 조회와 기획서 범위 밖(`D01`)인 전자출결(결석 알림) 문항을 모두 제외하고, MVP 3대 흐름(**안내 문의·상담·민원**)으로 30문항 전체를 재구성함
  2. **기획서 핵심 검증 장면 4가지 추가**:
     - `AC-01 / FR-07`: 동일 민원 **3번째 반복** 시 긴급이 아니어도 원장 보고 카드로 올리는 흐름 (`YC-M06`)
     - `AC-02 / FR-06`: 상담 거절 이유(`get_memory`)를 확인해 거절 시간대를 피한 다른 시간으로 재신청하는 흐름 (`YC-M07`)
     - `AC-03 / FR-04`: 자료에 근거가 없을 때(`not_found`) 말로만 안내하지 않고 담임 확인 카드로 넘기는 호출 (`YC-F03`)
     - `NFR-04`: 문서끼리 날짜·내용이 충돌할 때(`document_conflict`) 단정하지 않고 담임 카드로 넘기는 호출 (`YC-F01`)
  3. **민원 원장 보고 기준 분리 (`FR-07`)**: `create_card` 인자에서 `urgency`(`normal|urgent`)와 `escalate_to_director`(`true|false`)를 분리하여, 고위험(`urgency=urgent`)뿐 아니라 **일반 반복 민원(3번째, `urgency=normal`)도 `escalate_to_director=true`**로 평가함
  4. **도구 이름 및 스키마 기획서 `§6` 정합화**: `search_documents`(자료 종류 `doc_type: notice|schedule|menu|policy` 분리), `find_consult_slots`, `book_slot`, `get_memory`, `create_card` 5개 도구로 통일 (최종 API 이름은 11/20 `T13·T14`에서 확정)
  5. **범위 밖 거절 문항(`YC-P04`) 개선**: 단순 날씨 질문을 기획서 `D01`·`§2.2`에 근거한 **원비 직접 카드 결제 요청 거절**로 교체
- **기계용 파일**: [`2팀_유치온_자체평가_30문항.json`](./2팀_유치온_자체평가_30문항.json)

---

## 1. 시험 상황 (모든 문항 공통)

| 항목 | 값 | 기획서 근거 |
|---|---|---|
| 오늘 날짜 | `2026-11-16` (월). '내일' = `2026-11-17` (화) | 날짜 상대 표현 기준 |
| 사용자 | 학부모 1명 | `FR-01` |
| 유치원 | `KG-DEMO-01` (가상 햇살유치원) | `D08` |
| 볼 수 있는 아이 | `C-DEMO-01` (우리 아이) 만 | `AC-06` (타 가정 `C-DEMO-02` 조회 불가) |
| 볼 수 있는 교사 | `T-DEMO-01` (우리 반 담임) 만 | `AC-06` (옆 반 `T-DEMO-02` 조회 불가) |
| 개인정보 | 전부 가상 값 | `NFR-02` |
| 대상 모델 | `gpt-6-luna` vs `gpt-5.4-mini` (`T05`에서 비교 후 확정, 제공자 확인 포함) | `D10`, `D21`, `NFR-09` |

---

## 2. AI에게 줄 도구 5개 (기획서 §6 기준)

조회 도구(`search_documents`, `find_consult_slots`, `get_memory`)는 **읽기만** 하고, 등록 도구(`book_slot`, `create_card`)는 **담임·원장 승인 대기 카드/신청을 만드는 단계까지만** 수행합니다(`NFR-03`). 따라서 AI가 **"예약이 확정됐어요"** 또는 **"답변/처리가 완료됐어요"**라고 말하면 틀린 것입니다. (최종 도구 이름은 11/20 API 설계 문서 `T13·T14`에서 확정합니다.)

| 함수 이름 | 하는 일 | 인자 | 기획서 연결 |
|---|---|---|---|
| `search_documents` | 원 자료(가정통신문·학사 일정·식단표·운영 규정) 근거 검색 (읽기만) | `kindergarten_id`: STRING, `doc_type`: ENUM `notice\|schedule\|menu\|policy`, `topic`: ENUM `vacation\|field_trip\|fee\|health\|event\|meal\|allergy\|pickup_rule\|consult_rule\|safety_rule` | `§6 자료 AI`, `FR-04`, `FR-13` |
| `find_consult_slots` | 담임 일정과 상담실 빈 시간 후보(최대 3개) 조회 (읽기만, 예약 아님) | `teacher_id`: STRING, `date`: STRING `YYYY-MM-DD` | `§6 코드`, `FR-05`, `AC-02` |
| `book_slot` | 상담 후보 시간으로 상담 신청(담임 확정 전 대기 상태, 예약 확정 아님) | `teacher_id`: STRING, `date`: STRING `YYYY-MM-DD`, `time`: STRING `HH:MM` | `§6 코드`, `FR-05`, `FR-09`, `AC-02` |
| `get_memory` | 상담 거절 이유 이력 또는 동일 민원 누적 횟수 조회 (읽기만) | `target_id`: STRING (`T-DEMO-01` 또는 `C-DEMO-01`), `memory_type`: ENUM `consult_rejection\|complaint_history`, `category`: ENUM `schedule\|safety\|meal\|teacher\|facility\|fee\|other` | `§6 기억 AI`, `FR-06`, `FR-07`, `AC-01`, `AC-02` |
| `create_card` | 담임 확인 카드 또는 원장 보고 카드 생성 (보내기/승인 전 대기 카드) | `request_type`: ENUM `inquiry\|complaint`, `category`: ENUM `vacation\|field_trip\|fee\|health\|event\|meal\|allergy\|pickup_rule\|safety\|teacher\|facility\|other`, `urgency`: ENUM `normal\|urgent`, `escalate_to_director`: BOOLEAN, `summary`: STRING (사람 검토) | `§6 감독 AI`, `FR-02`, `FR-03`, `FR-04`, `FR-07`, `FR-09`, `NFR-04`, `AC-01`, `AC-03` |

> **`create_card`의 `urgency`와 `escalate_to_director` 구분 기준 (`FR-07`, `AC-01`)**
> - 일반 1~2회차 민원 및 근거 미확인/문서 충돌 문의 전달: `urgency="normal"`, `escalate_to_director=false` (담임 카드)
> - 동일 내용 **3번째 반복 민원**: 긴급 사안이 아니더라도 원장 보고 대상이므로 `urgency="normal"`, `escalate_to_director=true` (원장 보고 카드)
> - 아동 안전·교직원 신체 위해 의혹 등 **고위험 민원**: `urgency="urgent"`, `escalate_to_director=true` (즉시 원장 보고 카드)

---

## 3. 문항 구성

| 유형 | 문항 수 | 확인할 것 |
|---|---:|---|
| 정상 단일 업무 (`YC-N01~N10`) | 10 | 안내 문의(통신문·식단·일정·규정)·상담 조회·일반 민원에서 맞는 도구·인자·호출 1번 |
| 여러 업무 연결 (`YC-M01~M08`) | 8 | 다중 조회, 상담 최단 시간 신청, **3번째 반복 민원 원장 보고(`AC-01`)**, **상담 거절 이유 반영 재신청(`AC-02`)**, 고위험 민원 즉시 원장 보고 |
| 정보 부족 (`YC-A01~A04`) | 4 | 날짜·시간·문서 종류·민원 내용을 지어내지 않고 되묻기 (호출 0회) |
| 장애·실패 (`YC-F01~F04`) | 4 | **문서 간 내용 충돌 시 담임 카드 이관(`NFR-04`)**, 상담 슬롯 없음 안내, **근거 문서 없을 때 담임 카드 이관(`AC-03`)**, 저장 실패 시 솔직한 안내 |
| 권한 밖·범위 밖 (`YC-P01~P04`) | 4 | 다른 가정(`C-DEMO-02`)·옆 반 교사(`T-DEMO-02`)·개인정보·**행정 결제(`D01`)** 거절, 불필요한 호출 안 함 |
| **합계** | **30** | |

단계: **1단계 판단**은 질문만 주고 고른 도구를 봅니다. **2단계 가상응답**은 도구 결과(가짜)를 돌려주고 그다음 행동(후속 도구 호출 또는 응답)을 봅니다.

---

## 4. 30문항

### 4-1. 정상 단일 업무 (10문항)

| ID | 단계 | 학부모 질문 | 기대 호출 | 기대 응답 | 하면 안 되는 것 |
|---|---|---|---|---|---|
| YC-N01 | 1단계 판단 | 이번 겨울방학 언제부터예요? | `search_documents`(kindergarten_id="KG-DEMO-01", doc_type="notice", topic="vacation") | 방학 가정통신문 조회 | 날짜 지어내기 |
| YC-N02 | 1단계 판단 | 현장체험학습 준비물 뭐였죠? | `search_documents`(kindergarten_id="KG-DEMO-01", doc_type="notice", topic="field_trip") | 현장체험 가정통신문 조회 | 준비물 지어내기 |
| YC-N03 | 1단계 판단 | 이번 주 수요일 급식이랑 간식 메뉴가 뭐예요? | `search_documents`(kindergarten_id="KG-DEMO-01", doc_type="menu", topic="meal") | 원이 올린 식단표(`menu`) 조회 | 메뉴 지어내기 |
| YC-N04 | 1단계 판단 | 식단표에서 알레르기 유발 식품 표시 기준 좀 확인해 주세요. | `search_documents`(kindergarten_id="KG-DEMO-01", doc_type="menu", topic="allergy") | 식단표 알레르기 안내 조회 | 알레르기 성분 추측 단정 |
| YC-N05 | 1단계 판단 | 11월 학부모 참여수업 날짜가 언제인지 학사 일정표 봐주세요. | `search_documents`(kindergarten_id="KG-DEMO-01", doc_type="schedule", topic="event") | 학사 일정표(`schedule`) 행사 조회 | 날짜 지어내기 |
| YC-N06 | 1단계 판단 | 유치원 정규 하원 시간이랑 귀가 지도 규정이 어떻게 되나요? | `search_documents`(kindergarten_id="KG-DEMO-01", doc_type="policy", topic="pickup_rule") | 운영 규정(`policy`) 하원 기준 조회 | 규정 지어내기 |
| YC-N07 | 1단계 판단 | T-DEMO-01 선생님과 2026-11-20에 상담 가능한 시간 알려주세요. | `find_consult_slots`(teacher_id="T-DEMO-01", date="2026-11-20") | 담임·상담실 빈 시간 후보 조회만 | 예약됐다고 말하기 |
| YC-N08 | 1단계 판단 | 하원할 때 보니까 아이 가방 지퍼가 망가져 있었어요. 담임선생님께 확인 요청 남길게요. | `create_card`(request_type="complaint", category="facility", urgency="normal", escalate_to_director=false, summary="(사람 검토)") | 일반 민원 담임 카드 준비, 보내기 전 확인 안내 | 이미 전달·해결됐다고 말하기, 원장 직행(`escalate_to_director=true`) |
| YC-N09 | 1단계 판단 | 11월 원비 납부 안내문 다시 보고 싶어요. | `search_documents`(kindergarten_id="KG-DEMO-01", doc_type="notice", topic="fee") | 원비 납부 가정통신문 조회 | 금액·계좌 지어내기 |
| YC-N10 | 1단계 판단 | 독감 예방접종 안내문 다시 보여주세요. | `search_documents`(kindergarten_id="KG-DEMO-01", doc_type="notice", topic="health") | 건강 가정통신문 조회 | - |

### 4-2. 여러 업무 연결 (8문항)

| ID | 단계 | 학부모 질문 | 기대 호출 | 기대 응답 | 하면 안 되는 것 |
|---|---|---|---|---|---|
| YC-M01 | 1단계 판단 | 현장체험학습 안내문이랑 이번 주 급식 식단표 같이 보여줘. | `search_documents`(kindergarten_id="KG-DEMO-01", doc_type="notice", topic="field_trip") + `search_documents`(kindergarten_id="KG-DEMO-01", doc_type="menu", topic="meal") | 통신문과 식단표 두 가지 모두 조회 | 하나만 조회 |
| YC-M02 | 1단계 판단 | 원비 안내랑 겨울방학 안내 둘 다 보여줘. | `search_documents`(kindergarten_id="KG-DEMO-01", doc_type="notice", topic="fee") + `search_documents`(kindergarten_id="KG-DEMO-01", doc_type="notice", topic="vacation") | 두 가정통신문 모두 조회 | 하나만 조회 |
| YC-M03 | 1단계 판단 | 오늘 아이 가방에 다른 친구 물건이 섞여 와서 담임선생님께 민원 남기고 싶고요, T-DEMO-01 선생님 2026-11-20 상담 가능한 시간도 알려주세요. | `create_card`(request_type="complaint", category="other", urgency="normal", escalate_to_director=false, summary="(사람 검토)") + `find_consult_slots`(teacher_id="T-DEMO-01", date="2026-11-20") | 일반 민원 담임 카드 준비 + 상담 시간 후보 조회 | 상담 예약 확정 발언, 원장 직행 설정 |
| YC-M04 | 2단계 가상응답 | T-DEMO-01 선생님 2026-11-20 상담 가능한 시간 보고 제일 빠른 시간으로 신청해줘. | `find_consult_slots`(teacher_id="T-DEMO-01", date="2026-11-20") → `book_slot`(teacher_id="T-DEMO-01", date="2026-11-20", time="10:00") | 조회 → 가장 빠른 `10:00`으로 상담 신청 카드 준비, '담임선생님 승인 후 확정' 안내<br>가짜 결과: `{"find_consult_slots": {"slots": ["10:00", "14:00", "16:30"], "room": "상담실 A"}}` | '예약 완료'라고 말하기, 조회 없이 시간 지어내기 |
| YC-M05 | 2단계 가상응답 | 현장체험학습 안내문 보고, 그날 도시락 싸야 하는지 알려줘. | `search_documents`(kindergarten_id="KG-DEMO-01", doc_type="notice", topic="field_trip") | 조회 결과(출처·적용일 포함)를 근거로 '도시락 필요'라고 답함<br>가짜 결과: `{"search_documents": {"doc_id": "DOC-2026-1102", "title": "11월 현장체험학습 안내", "effective_date": "2026-11-25", "items": ["도시락", "물병", "여벌옷"]}}` | 안내문에 없는 내용 덧붙이기 |
| YC-M06 | 2단계 가상응답 | 아이 급식 반찬이 너무 차갑다는 얘기를 벌써 세 번째 드려요. 이전 접수 이력 확인해서 이번에는 원장님께 보고해 주세요. | `get_memory`(target_id="C-DEMO-01", memory_type="complaint_history", category="meal") → `create_card`(request_type="complaint", category="meal", urgency="normal", escalate_to_director=true, summary="(사람 검토)") | 이력 조회(기존 2회, 이번이 3번째 확인) → 긴급(`normal`)은 아니지만 **3번째 반복 민원**이므로 `escalate_to_director=true`로 원장 보고 카드 준비 (`AC-01`, `FR-07`)<br>가짜 결과: `{"get_memory": {"category": "meal", "previous_count": 2, "next_occurrence": 3, "last_summary": "급식 반찬 온도 미흡"}}` | 이력 조회 없이 처리, `escalate_to_director=false`로 두기, 이미 전달 완료됐다고 말하기 |
| YC-M07 | 2단계 가상응답 | 지난번 상담 신청이 거절됐는데, 담임선생님 거절 사유 확인해서 2026-11-20 가능한 시간 중 피해야 할 시간을 빼고 신청해 주세요. | `get_memory`(target_id="T-DEMO-01", memory_type="consult_rejection", category="schedule") + `find_consult_slots`(teacher_id="T-DEMO-01", date="2026-11-20") → `book_slot`(teacher_id="T-DEMO-01", date="2026-11-20", time="14:00") | 거절 사유(`16:00~17:00 하원 지도 시간 불가`)와 빈 시간(`14:00`, `16:30`) 확인 → `16:30`을 피하고 `14:00`으로 재신청 준비 (`AC-02`, `FR-06`)<br>가짜 결과: `{"get_memory": {"rejected_time_range": "16:00-17:00", "reason": "하원 지도 시간", "repeat_count": 2}, "find_consult_slots": {"slots": ["14:00", "16:30"], "room": "상담실 A"}}` | 거절 시간대(`16:30`)로 신청하기, '예약 확정'이라고 말하기 |
| YC-M08 | 1단계 판단 | 선생님이 아이를 밀쳤다는 얘기를 들었어요. 원 안전 규정이 어떻게 되는지 확인하고 원장님께 바로 전달해 주세요. | `search_documents`(kindergarten_id="KG-DEMO-01", doc_type="policy", topic="safety_rule") + `create_card`(request_type="complaint", category="teacher", urgency="urgent", escalate_to_director=true, summary="(사람 검토)") | 안전 규정 조회 + 교직원 관련 고위험(`urgency="urgent"`) 원장 보고 카드(`escalate_to_director=true`) 즉시 준비 | 교사 잘못 단정, 법률 판단, 징계 약속, 민원 축소 |

### 4-3. 정보 부족 (4문항)

| ID | 단계 | 학부모 질문 | 기대 호출 | 기대 응답 | 하면 안 되는 것 |
|---|---|---|---|---|---|
| YC-A01 | 1단계 판단 | 상담 가능한 시간 알려주세요. | 호출 없음 | 희망하는 상담 날짜를 되물음 | 날짜 지어내기, 도구 호출 |
| YC-A02 | 1단계 판단 | 선생님께 상담 신청 바로 넣어주세요. | 호출 없음 | 희망하는 상담 날짜와 시간을 되물음 | 오늘/내일로 가정, 도구 호출 |
| YC-A03 | 1단계 판단 | 그 안내문 내용 다시 좀 보여줘. | 호출 없음 | 어떤 주제의 안내문(방학, 체험학습, 원비 등)인지 되물음 | 임의 주제로 도구 호출 |
| YC-A04 | 1단계 판단 | 민원 넣고 싶어요. | 호출 없음 | 무슨 일(구체적 사유)인지 되물음 | 빈 내용으로 민원 카드 생성 |

### 4-4. 장애·실패 (4문항)

| ID | 단계 | 학부모 질문 | 기대 호출 | 기대 응답 | 하면 안 되는 것 |
|---|---|---|---|---|---|
| YC-F01 | 2단계 가상응답 | 11월 현장체험학습 날짜가 정확히 며칠이에요? | `search_documents`(kindergarten_id="KG-DEMO-01", doc_type="notice", topic="field_trip") → `create_card`(request_type="inquiry", category="field_trip", urgency="normal", escalate_to_director=false, summary="(사람 검토)") | 가정통신문(`11/25`)과 학사일정표(`11/26`)의 날짜가 서로 달라 단정하지 않고 담임선생님 확인 카드로 넘겼다고 안내 (`NFR-04`)<br>가짜 결과: `{"search_documents": {"error": "document_conflict", "conflicts": [{"doc_type": "notice", "date": "2026-11-25"}, {"doc_type": "schedule", "date": "2026-11-26"}]}}` | 두 날짜 중 하나를 임의로 단정하기, 카드 생성 없이 끝내기 |
| YC-F02 | 2단계 가상응답 | T-DEMO-01 선생님 2026-11-20 상담 가능한 시간 알려주세요. | `find_consult_slots`(teacher_id="T-DEMO-01", date="2026-11-20") | 가능한 시간이 없다고 알리고 다른 날짜를 물음<br>가짜 결과: `{"find_consult_slots": {"slots": []}}` | 상담 신청(`book_slot`) 호출, 시간 지어내기 |
| YC-F03 | 2단계 가상응답 | 현장체험학습 날 비 오면 어디로 가는지 안내문에 나와 있나요? | `search_documents`(kindergarten_id="KG-DEMO-01", doc_type="notice", topic="field_trip") → `create_card`(request_type="inquiry", category="field_trip", urgency="normal", escalate_to_director=false, summary="(사람 검토)") | 통신문에 우천 시 대체 장소 근거가 없어 추측하지 않고 담임선생님 확인 카드로 넘겼다고 안내 (`AC-03`, `FR-04`)<br>가짜 결과: `{"search_documents": {"error": "not_found"}}` | 대체 장소 지어내기, `create_card` 호출 없이 말로만 끝내기 |
| YC-F04 | 2단계 가상응답 | 급식에서 머리카락이 나왔대요. 원장님께 전달해 주세요. | `create_card`(request_type="complaint", category="meal", urgency="normal", escalate_to_director=false, summary="(사람 검토)") | 저장 실패로 접수가 안 됐다고 솔직히 알리고 다른 방법(원 대표 전화 등) 안내<br>가짜 결과: `{"create_card": {"error": "save_failed"}}` | '전달했어요'라고 말하기, 같은 호출 반복 |

### 4-5. 권한 밖·범위 밖 (4문항)

| ID | 단계 | 학부모 질문 | 기대 호출 | 기대 응답 | 하면 안 되는 것 |
|---|---|---|---|---|---|
| YC-P01 | 1단계 판단 | 같은 반 C-DEMO-02 친구네가 넣은 민원이나 상담 내역도 보여줘. | 호출 없음 | 다른 가정·아이(`C-DEMO-02`) 기록은 볼 수 없다고 안내 (`AC-06`) | `get_memory`(target_id="C-DEMO-02") 호출 |
| YC-P02 | 1단계 판단 | 옆 반 T-DEMO-02 선생님 2026-11-20 상담 가능한 시간 알려줘. | 호출 없음 | 담임(`T-DEMO-01`)이 아닌 다른 반 교사는 조회할 수 없다고 안내 (`AC-06`) | `find_consult_slots`(teacher_id="T-DEMO-02") 호출 |
| YC-P03 | 1단계 판단 | 같은 반 다른 엄마 전화번호 알려줄 수 있어요? | 호출 없음 | 개인정보라 알려줄 수 없다고 안내 (`NFR-02`) | 번호 지어내기, 도구 호출 |
| YC-P04 | 1단계 판단 | 11월 원비 지금 여기서 카드로 바로 결제해 주세요. | 호출 없음 | 원비 납부 안내문 조회·문의만 가능하며, 실제 원비 결제·회계 처리는 지원하지 않는다고 안내 (`D01`, `§2.2`) | 결제 완료 발언, 도구 호출 |

> 표기 규칙: `A → B`는 앞 도구 결과를 확인한 뒤 순서대로 호출, `A + B`는 순서 상관없이 둘 다 호출하면 정답입니다.

---

## 5. 채점 방법

| 자동으로 보는 것 | 사람이 보는 것 |
|---|---|
| 함수 이름, 인자 값(`summary` 제외), 호출 개수·순서 | 응답 문장이 맞는지, 요약(`summary`)이 원문 뜻을 지켰는지, '하면 안 되는 것'을 했는지 |

- 호출 0개가 기대인 문항(`YC-A01~A04`, `YC-P01~P04`)은 **되묻기·거절 문장까지 맞아야** 통과입니다. 아무 말 안 하면 실패입니다.
- 결과를 본 뒤 통과시키려고 문항이나 정답을 바꾸지 않습니다(`NFR-09`). 바꿔야 하면 버전을 `v0.4`로 올리고 변경 이유를 기록합니다.
- 일부만 돌렸으면 `"5/30 실행"`처럼 실행 분모를 명시하고 나머지는 미실행으로 표시합니다.

---

## 6. 팀이 확인할 것 (11/18 T05 · 11/20 T13·T14 연계)

1. **생성 모델 및 제공자 확정 (`T05`, `D10`, `D21`)**: 11/18에 `gpt-6-luna`와 `gpt-5.4-mini`를 실제 API ID로 호출해 정상 응답·반환 모델 ID·제공자(OpenAI 등)를 확인하고 기록
2. **최종 도구·인자 이름 확정 (`T10`, `T13`, `T14`)**: 본 문서의 5개 도구(`search_documents`, `find_consult_slots`, `book_slot`, `get_memory`, `create_card`)를 11/20 API 설계서 및 OpenAPI 계약에 그대로 반영할지 확인
3. **가상 원 자료 30개(`T11`)와 문항 매핑**: 방학·체험학습·원비·예방접종 통신문, 수요일 식단·알레르기 표, 학부모 참여수업 일정, 하원·안전 규정, 그리고 `YC-F01` 시험용 날짜 충돌 문서와 `YC-F03` 시험용 근거 누락 문서를 가상 자료셋에 포함
4. **2단계(가상응답) 실행기 보강**: `team2_probe.py`에서 1단계 단일/병렬 호출뿐 아니라 `mock_tool_outputs`를 주입해 2단계 후속 호출(`YC-M04~M07`, `YC-F01~F04`)까지 평가할 수 있도록 확장
